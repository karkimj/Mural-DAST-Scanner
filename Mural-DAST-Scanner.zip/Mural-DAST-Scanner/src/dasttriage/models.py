"""Engine-agnostic finding schema.

Every scan engine (ZAP, Nuclei, Burp, ...) is normalized into a `RawFinding`
before it touches the database. Keeping this layer thin and strict is what lets
history matching and triage work across engines and across time.
"""
from __future__ import annotations

import enum
from datetime import datetime, timezone

from pydantic import BaseModel, Field


class Severity(str, enum.Enum):
    info = "info"
    low = "low"
    medium = "medium"
    high = "high"
    critical = "critical"

    @property
    def rank(self) -> int:
        return {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}[self.value]


# Confidence as reported by the engine; distinct from AI-triage confidence.
class Confidence(str, enum.Enum):
    low = "low"
    medium = "medium"
    high = "high"
    confirmed = "confirmed"


class TriageState(str, enum.Enum):
    """Lifecycle state of an *issue* (a deduplicated finding across scans)."""
    new = "new"                      # seen for the first time, not yet reviewed
    open = "open"                    # confirmed real / under remediation
    false_positive = "false_positive"
    accepted_risk = "accepted_risk"
    fixed = "fixed"                  # absent from a later scan after being open
    reopened = "reopened"            # reappeared after being marked fixed


# States whose findings are kept out of the clean report body.
SUPPRESSED_STATES = {TriageState.false_positive}
# States that still carry risk but are acknowledged; shown in an appendix.
ACKNOWLEDGED_STATES = {TriageState.accepted_risk}


class Evidence(BaseModel):
    """The request/response pair (or raw proof) backing one occurrence."""
    url: str = ""
    method: str = "GET"
    param: str | None = None
    attack: str | None = None          # the payload the engine sent
    request: str | None = None         # raw HTTP request, redacted before storage
    response_snippet: str | None = None
    other: dict[str, str] = Field(default_factory=dict)


class RawFinding(BaseModel):
    """A single finding as emitted by one engine for one scan run.

    `fingerprint` is filled in by the fingerprint module, not the engine.
    """
    engine: str                        # "zap" | "nuclei" | "burp" | ...
    engine_rule_id: str                # e.g. ZAP pluginId, nuclei template-id
    name: str
    severity: Severity
    confidence: Confidence = Confidence.medium
    url: str
    method: str = "GET"
    param: str | None = None
    cwe: int | None = None
    description: str = ""
    remediation: str = ""
    references: list[str] = Field(default_factory=list)
    evidence: Evidence = Field(default_factory=Evidence)
    fingerprint: str | None = None     # set by fingerprint.compute()
    raw: dict = Field(default_factory=dict)  # original engine payload, for audit

    def with_fingerprint(self, fp: str) -> "RawFinding":
        self.fingerprint = fp
        return self


def utcnow() -> datetime:
    return datetime.now(timezone.utc)
