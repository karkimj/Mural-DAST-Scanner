from pathlib import Path

import pytest

from dasttriage import report as report_mod
from dasttriage import service
from dasttriage.db import Target, init_db, make_engine, make_session
from dasttriage.engines import get_engine
from dasttriage.engines.redact import redact_text
from dasttriage.models import Severity

FIX = Path(__file__).parent / "fixtures"


def test_zap_parse():
    eng = get_engine("zap")
    findings = eng.parse((FIX / "zap_sample.json").read_text())
    assert len(findings) == 3
    sqli = [f for f in findings if f.engine_rule_id == "40018"][0]
    assert sqli.severity == Severity.high
    assert sqli.cwe == 89
    assert sqli.param == "id"


def test_nuclei_parse():
    eng = get_engine("nuclei")
    findings = eng.parse((FIX / "nuclei_sample.jsonl").read_text())
    assert len(findings) == 2
    log4j = [f for f in findings if "log4j" in f.name.lower()][0]
    assert log4j.severity == Severity.critical
    assert log4j.cwe == 502


def test_finalize_redacts_and_fingerprints():
    eng = get_engine("zap")
    raw = eng.parse((FIX / "zap_sample.json").read_text())
    done = eng.finalize(raw)
    assert all(f.fingerprint for f in done)


def test_redaction_patterns():
    assert "[JWT_REDACTED]" in redact_text(
        "token eyJhbGc.eyJzdWI.sig here")
    assert "[EMAIL_REDACTED]" in redact_text("user mj@innovora.com logged in")
    assert "[REDACTED]" in redact_text("Authorization: Bearer abc123.def")


@pytest.fixture()
def populated():
    eng = make_engine("sqlite:///:memory:")
    init_db(eng)
    s = make_session(eng)()
    service.import_file(s, "staging", "zap", FIX / "zap_sample.json", full_scan=True)
    t = s.query(Target).first()
    return s, t


def test_reports_render(populated):
    s, t = populated
    html = report_mod.to_html(s, t)
    assert "DAST findings" in html and "SQL Injection" in html
    sarif = report_mod.to_sarif(s, t)
    assert '"version": "2.1.0"' in sarif
    import json
    data = json.loads(report_mod.to_json(s, t))
    assert data["summary"]["live_total"] == 3


def test_clean_report_excludes_false_positives(populated):
    s, t = populated
    from dasttriage.db import Issue
    from dasttriage.lifecycle import set_triage
    from dasttriage.models import TriageState
    hdr = s.query(Issue).filter(Issue.engine_rule_id == "10021").one()
    set_triage(s, hdr, TriageState.false_positive, actor="h", reason="noise")
    s.commit()
    import json
    data = json.loads(report_mod.to_json(s, t))
    assert data["summary"]["live_total"] == 2
    assert data["summary"]["false_positive_total"] == 1
    names = [f["name"] for f in data["findings"]]
    assert all("X-Content-Type" not in n for n in names)
