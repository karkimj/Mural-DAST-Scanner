"""Authentication for the web UI.

Deliberately simple and self-contained, but done properly:
  * Credentials come from the environment; the values baked in here are only
    development defaults. Set DAST_WEB_USER / DAST_WEB_PASSWORD (or, better,
    DAST_WEB_PASSWORD_HASH) in any real deployment.
  * The password is never compared as plaintext: we store a PBKDF2-HMAC-SHA256
    hash and verify with a constant-time comparison.
  * Basic per-IP rate limiting slows brute force.

This gates a tool that can launch scans, so it must sit behind HTTPS and real
credentials before being exposed. The login form posts over whatever transport
the reverse proxy provides — terminate TLS in front of it.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import time

# --- development defaults (override via env in production) ---
_DEFAULT_USER = "mural"
_DEFAULT_PASSWORD = "Ansrn17!!"

_ITERATIONS = 240_000
_ALGO = "sha256"


def _hash_password(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac(_ALGO, password.encode("utf-8"), salt, _ITERATIONS)


def _encode(salt: bytes, digest: bytes) -> str:
    return f"pbkdf2_{_ALGO}${_ITERATIONS}${salt.hex()}${digest.hex()}"


def _decode(encoded: str) -> tuple[int, bytes, bytes]:
    _, iters, salt_hex, dig_hex = encoded.split("$")
    return int(iters), bytes.fromhex(salt_hex), bytes.fromhex(dig_hex)


def make_hash(password: str) -> str:
    """Produce a storable hash string (use this to generate DAST_WEB_PASSWORD_HASH)."""
    salt = secrets.token_bytes(16)
    return _encode(salt, _hash_password(password, salt))


class Auth:
    """Holds the single operator credential and does rate-limited verification."""

    def __init__(self) -> None:
        self.username = os.environ.get("DAST_WEB_USER", _DEFAULT_USER)
        encoded = os.environ.get("DAST_WEB_PASSWORD_HASH")
        if not encoded:
            plaintext = os.environ.get("DAST_WEB_PASSWORD", _DEFAULT_PASSWORD)
            encoded = make_hash(plaintext)
        self._iters, self._salt, self._digest = _decode(encoded)
        # per-IP throttle: ip -> [fail_count, locked_until_epoch]
        self._attempts: dict[str, list[float]] = {}
        self.max_fails = 5
        self.lock_seconds = 300

    def _verify_password(self, password: str) -> bool:
        candidate = hashlib.pbkdf2_hmac(
            _ALGO, password.encode("utf-8"), self._salt, self._iters
        )
        return hmac.compare_digest(candidate, self._digest)

    def locked_for(self, ip: str) -> int:
        rec = self._attempts.get(ip)
        if not rec:
            return 0
        _, until = rec
        remaining = int(until - time.time())
        return max(0, remaining)

    def check(self, ip: str, username: str, password: str) -> bool:
        if self.locked_for(ip) > 0:
            return False
        # constant-time on both fields; evaluate both to avoid username oracle
        user_ok = hmac.compare_digest(username, self.username)
        pass_ok = self._verify_password(password)
        if user_ok and pass_ok:
            self._attempts.pop(ip, None)
            return True
        rec = self._attempts.get(ip, [0, 0.0])
        rec[0] += 1
        if rec[0] >= self.max_fails:
            rec[1] = time.time() + self.lock_seconds
            rec[0] = 0
        self._attempts[ip] = rec
        return False
