"""Scan configuration and scope enforcement.

The scanner refuses to run without a scope file. Pointing a portable scanner at
the wrong host is an easy and costly mistake, so scope is mandatory and checked
in one place that every engine and the verifier agent must call.
"""
from __future__ import annotations

import fnmatch
from pathlib import Path
from urllib.parse import urlsplit

import yaml
from pydantic import BaseModel, Field


class VerifierPolicy(BaseModel):
    # Active exploit verifiers (sqlmap/commix) are off unless explicitly allowed
    # per target, because they send real attack traffic.
    allow_active_exploit: bool = False
    max_requests: int = 25
    sqlmap_level: int = 1
    sqlmap_risk: int = 1


class ScopeConfig(BaseModel):
    """Loaded from scope.yaml. Defines what may be scanned and how hard."""
    name: str = "default"
    include_hosts: list[str] = Field(default_factory=list)   # glob patterns ok
    exclude_hosts: list[str] = Field(default_factory=list)
    exclude_paths: list[str] = Field(default_factory=list)   # path globs
    max_rps: float = 10.0
    verifier: VerifierPolicy = Field(default_factory=VerifierPolicy)

    @classmethod
    def load(cls, path: str | Path) -> "ScopeConfig":
        data = yaml.safe_load(Path(path).read_text()) or {}
        cfg = cls(**data)
        if not cfg.include_hosts:
            raise ValueError(
                "scope file must list at least one include_hosts entry; "
                "refusing to scan an unbounded target set"
            )
        return cfg

    def _host_of(self, url: str) -> str:
        parts = urlsplit(url if "://" in url else f"http://{url}")
        return (parts.hostname or "").lower()

    def _path_of(self, url: str) -> str:
        parts = urlsplit(url if "://" in url else f"http://{url}")
        return parts.path or "/"

    def in_scope(self, url: str) -> bool:
        host = self._host_of(url)
        if not host:
            return False
        if any(fnmatch.fnmatch(host, p.lower()) for p in self.exclude_hosts):
            return False
        if not any(fnmatch.fnmatch(host, p.lower()) for p in self.include_hosts):
            return False
        path = self._path_of(url)
        if any(fnmatch.fnmatch(path, p) for p in self.exclude_paths):
            return False
        return True

    def assert_in_scope(self, url: str) -> None:
        if not self.in_scope(url):
            raise PermissionError(f"target out of scope: {url}")
