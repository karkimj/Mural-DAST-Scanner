"""High-level orchestration used by the CLI (and later the API).

Keeps the CLI thin: a scan run is open scan -> ingest each finding -> optionally
close absent issues -> expire accepted risks -> commit.
"""
from __future__ import annotations

from pathlib import Path

from sqlalchemy.orm import Session

from . import lifecycle
from .config import ScopeConfig
from .db import ScanRun
from .engines import get_engine
from .models import RawFinding, utcnow


def run_scan(
    session: Session,
    target_name: str,
    findings: list[RawFinding],
    engines_used: list[str],
    full_scan: bool = True,
) -> dict:
    """Ingest a batch of already-fingerprinted findings as one scan run."""
    target = lifecycle.get_or_create_target(session, target_name)
    scan = ScanRun(target_id=target.id, engines=engines_used, meta={})
    session.add(scan)
    session.flush()

    expired = lifecycle.expire_accepted_risks(session)
    new_count = 0
    for f in findings:
        _, is_new = lifecycle.ingest(session, target, scan, f)
        new_count += int(is_new)

    closed = lifecycle.close_absent_issues(session, target, scan) if full_scan else []
    scan.finished_at = utcnow()
    session.commit()
    return {
        "scan_id": scan.id,
        "target": target_name,
        "ingested": len(findings),
        "new_issues": new_count,
        "closed_as_fixed": len(closed),
        "expired_accepted": len(expired),
    }


def import_file(
    session: Session,
    target_name: str,
    engine_name: str,
    path: str | Path,
    full_scan: bool = False,
) -> dict:
    eng = get_engine(engine_name)
    raw = eng.parse(Path(path).read_text())
    findings = eng.finalize(raw)
    return run_scan(session, target_name, findings, [engine_name],
                    full_scan=full_scan)


def live_scan(
    session: Session,
    target_url: str,
    scope: ScopeConfig,
    engine_names: list[str],
    **engine_kwargs,
) -> dict:
    scope.assert_in_scope(target_url)
    all_findings: list[RawFinding] = []
    for name in engine_names:
        eng = get_engine(name, **engine_kwargs.get(name, {}))
        raw = eng.scan(target_url, scope)
        all_findings.extend(eng.finalize(raw))
    return run_scan(session, scope.name, all_findings, engine_names, full_scan=True)
