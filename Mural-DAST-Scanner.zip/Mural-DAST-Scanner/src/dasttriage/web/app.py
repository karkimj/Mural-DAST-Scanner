"""FastAPI web UI for dast-triage (Phase 1 platform).

Sections: overview, targets (CRUD + auth config + encrypted creds), scans
(run-now + queue + history), findings (+triage), reports, users (RBAC).
Schedules, scan-management and integrations arrive in later phases.
"""
from __future__ import annotations

import os
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import func, select
from starlette.middleware.sessions import SessionMiddleware

from pathlib import Path

from .. import report as report_mod
from .. import rbac
from ..crypto import encrypt
from ..db import (
    Credential, Integration, Issue, ScanJob, ScanProfile, ScanRun,
    Schedule, Target, User, init_db, make_engine, make_session,
)
from .. import integrations as integ_mod
from ..crypto import decrypt
from ..lifecycle import set_triage
from ..models import Severity, TriageState
from ..rbac import Role, role_at_least
from .. import worker
from .auth import Auth

_TEMPLATES = Path(__file__).parent / "templates"

app = FastAPI(title="dast-triage")
app.add_middleware(
    SessionMiddleware,
    secret_key=os.environ.get("DAST_SECRET_KEY", secrets.token_hex(32)),
    session_cookie="dast_session",
    https_only=os.environ.get("DAST_HTTPS_ONLY", "").lower() in ("1", "true", "yes"),
    same_site="lax",
)
templates = Jinja2Templates(directory=str(_TEMPLATES))
_ratelimit = Auth()  # reused only for per-IP login throttling
_engine = make_engine()
init_db(_engine)
_Session = make_session(_engine)


@app.on_event("startup")
def _startup():
    s = _Session()
    try:
        rbac.bootstrap(s)
    finally:
        s.close()
    worker.start(_Session)


def db():
    s = _Session()
    try:
        yield s
    finally:
        s.close()


class CurrentUser:
    def __init__(self, username: str, role: str):
        self.username = username
        self.role = role

    def can(self, minimum: Role) -> bool:
        return role_at_least(self.role, minimum)


def current_user(request: Request) -> CurrentUser:
    u = request.session.get("user")
    r = request.session.get("role")
    if not u:
        raise HTTPException(status_code=307, headers={"Location": "/login"})
    return CurrentUser(u, r or "viewer")


def require(minimum: Role):
    def dep(user: CurrentUser = Depends(current_user)) -> CurrentUser:
        if not user.can(minimum):
            raise HTTPException(403, f"requires {minimum.value} role")
        return user
    return dep


def _ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for")
    return xff.split(",")[0].strip() if xff else (request.client.host if request.client else "?")


def _ctx(request, user, **extra):
    d = {"user": user, "Role": Role, **extra}
    d.update(extra)
    return d


# --- auth ---------------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return RedirectResponse("/dashboard" if request.session.get("user") else "/login", 303)


@app.get("/login", response_class=HTMLResponse)
def login_form(request: Request):
    return templates.TemplateResponse(request, "login.html", {"error": None})


@app.post("/login", response_class=HTMLResponse)
def login(request: Request, username: str = Form(...), password: str = Form(...),
          s=Depends(db)):
    ip = _ip(request)
    if _ratelimit.locked_for(ip):
        return templates.TemplateResponse(
            request, "login.html",
            {"error": f"Too many attempts. Wait {_ratelimit.locked_for(ip)}s."},
            status_code=429)
    u = rbac.authenticate(s, username, password)
    if not u:
        # count the failure for throttling
        _ratelimit.check(ip, username, "\x00never")
        return templates.TemplateResponse(
            request, "login.html", {"error": "Invalid credentials."},
            status_code=401)
    _ratelimit._attempts.pop(ip, None)
    request.session["user"] = u.username
    request.session["role"] = u.role
    return RedirectResponse("/dashboard", 303)


@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/login", 303)


# --- overview -----------------------------------------------------------
@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db)):
    targets = s.scalars(select(Target)).all()
    counts = {sv.value: 0 for sv in Severity}
    totals = {"open": 0, "accepted": 0, "fp": 0, "fixed": 0}
    live_states = (TriageState.new.value, TriageState.open.value, TriageState.reopened.value)
    issues = s.scalars(select(Issue)).all()
    for i in issues:
        if i.state in live_states:
            totals["open"] += 1
            counts[i.severity] = counts.get(i.severity, 0) + 1
        elif i.state == TriageState.accepted_risk.value:
            totals["accepted"] += 1
        elif i.state == TriageState.false_positive.value:
            totals["fp"] += 1
        elif i.state == TriageState.fixed.value:
            totals["fixed"] += 1
    recent_jobs = s.scalars(select(ScanJob).order_by(ScanJob.id.desc()).limit(8)).all()
    active = s.scalar(select(func.count()).select_from(ScanJob)
                      .where(ScanJob.status.in_(["queued", "running"])))
    return templates.TemplateResponse(request, "overview.html", _ctx(
        request, user, targets=targets, counts=counts, totals=totals,
        recent_jobs=recent_jobs, active=active, sev_order=["critical","high","medium","low","info"]))


# --- targets ------------------------------------------------------------
def _parse_list(v: str) -> list[str]:
    return [x.strip() for x in (v or "").replace(",", "\n").splitlines() if x.strip()]


@app.get("/targets", response_class=HTMLResponse)
def targets_list(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db)):
    rows = []
    for t in s.scalars(select(Target)).all():
        rows.append({"t": t, "summary": report_mod.build_summary(s, t)})
    return templates.TemplateResponse(request, "targets.html", _ctx(request, user, rows=rows))


@app.get("/targets/new", response_class=HTMLResponse)
def target_new(request: Request, user: CurrentUser = Depends(require(Role.analyst))):
    return templates.TemplateResponse(request, "target_form.html",
                                      _ctx(request, user, target=None))


@app.get("/targets/{tid}/edit", response_class=HTMLResponse)
def target_edit(tid: int, request: Request,
                user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db)):
    t = s.get(Target, tid)
    if not t:
        raise HTTPException(404)
    cred = s.scalar(select(Credential).where(Credential.target_id == tid)
                    .order_by(Credential.id.desc()))
    return templates.TemplateResponse(request, "target_form.html",
                                      _ctx(request, user, target=t, cred=cred))


@app.post("/targets/save")
def target_save(
    request: Request,
    user: CurrentUser = Depends(require(Role.analyst)),
    s=Depends(db),
    tid: str = Form(""),
    name: str = Form(...),
    description: str = Form(""),
    environment: str = Form("prod"),
    criticality: str = Form("medium"),
    owner: str = Form(""),
    tags: str = Form(""),
    base_urls: str = Form(""),
    extra_hosts: str = Form(""),
    api_spec_url: str = Form(""),
    api_spec_type: str = Form(""),
    include_hosts: str = Form(""),
    exclude_hosts: str = Form(""),
    exclude_paths: str = Form(""),
    max_rps: float = Form(10.0),
    auth_method: str = Form("none"),
    auth_login_url: str = Form(""),
    auth_header_name: str = Form(""),
    auth_logged_in_regex: str = Form(""),
    cred_username: str = Form(""),
    cred_secret: str = Form(""),
    allow_active_exploit: str = Form(""),
    tech_hints: str = Form(""),
    notify_emails: str = Form(""),
    authorized: str = Form(""),
):
    t = s.get(Target, int(tid)) if tid else Target(name=name)
    if not tid:
        s.add(t)
    t.name = name
    t.description = description
    t.environment = environment
    t.criticality = criticality
    t.owner = owner
    t.tags = _parse_list(tags)
    t.base_urls = _parse_list(base_urls)
    t.extra_hosts = _parse_list(extra_hosts)
    t.api_spec_url = api_spec_url
    t.api_spec_type = api_spec_type
    t.include_hosts = _parse_list(include_hosts)
    t.exclude_hosts = _parse_list(exclude_hosts)
    t.exclude_paths = _parse_list(exclude_paths)
    t.max_rps = max_rps
    t.auth_method = auth_method
    t.auth_login_url = auth_login_url
    t.auth_header_name = auth_header_name
    t.auth_logged_in_regex = auth_logged_in_regex
    t.allow_active_exploit = bool(allow_active_exploit)
    t.tech_hints = _parse_list(tech_hints)
    t.notify_emails = _parse_list(notify_emails)
    was_authorized = t.authorized
    t.authorized = bool(authorized)
    if t.authorized and not was_authorized:
        t.authorized_by = user.username
        t.authorized_at = datetime.now(timezone.utc)
    s.flush()
    # credential (only replace secret if a new one was entered)
    if auth_method not in ("none", "") and (cred_username or cred_secret):
        cred = s.scalar(select(Credential).where(Credential.target_id == t.id)
                        .order_by(Credential.id.desc()))
        if cred is None:
            cred = Credential(target_id=t.id)
            s.add(cred)
        cred.kind = auth_method
        if cred_username:
            cred.username = cred_username
        if cred_secret:
            cred.secret_encrypted = encrypt(cred_secret)
    s.commit()
    return RedirectResponse(f"/targets/{t.id}", 303)


@app.get("/targets/{tid}", response_class=HTMLResponse)
def target_detail(tid: int, request: Request,
                  user: CurrentUser = Depends(current_user), s=Depends(db)):
    t = s.get(Target, tid)
    if not t:
        raise HTTPException(404)
    issues = s.scalars(select(Issue).where(Issue.target_id == tid)).all()
    rank = {x.value: x.rank for x in Severity}
    issues.sort(key=lambda i: (rank.get(i.severity, 0), i.last_seen or datetime.min),
                reverse=True)
    jobs = s.scalars(select(ScanJob).where(ScanJob.target_id == tid)
                     .order_by(ScanJob.id.desc()).limit(10)).all()
    profiles = s.scalars(select(ScanProfile)).all()
    return templates.TemplateResponse(request, "target.html", _ctx(
        request, user, target=t, issues=issues, jobs=jobs, profiles=profiles))


@app.post("/targets/{tid}/delete")
def target_delete(tid: int, user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db)):
    t = s.get(Target, tid)
    if t:
        # clean dependent rows
        for tbl in (Credential, ScanJob):
            for row in s.scalars(select(tbl).where(tbl.target_id == tid)).all():
                s.delete(row)
        s.delete(t)
        s.commit()
    return RedirectResponse("/targets", 303)


# --- scans --------------------------------------------------------------
@app.post("/targets/{tid}/scan")
def run_scan_now(tid: int, request: Request,
                 user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db),
                 profile_id: str = Form(""), engines: list[str] = Form(default=[])):
    t = s.get(Target, tid)
    if not t:
        raise HTTPException(404)
    prof = s.get(ScanProfile, int(profile_id)) if profile_id else None
    use_engines = engines or (prof.engines if prof else ["zap"])
    job = ScanJob(
        target_id=tid, profile_id=(prof.id if prof else None),
        engines=use_engines, status="queued", created_by=user.username,
        full_scan=(prof.full_scan if prof else True),
    )
    s.add(job)
    s.commit()
    return RedirectResponse(f"/targets/{tid}", 303)


@app.get("/scans", response_class=HTMLResponse)
def scans(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db)):
    jobs = s.scalars(select(ScanJob).order_by(ScanJob.id.desc()).limit(100)).all()
    tmap = {t.id: t.name for t in s.scalars(select(Target)).all()}
    return templates.TemplateResponse(request, "scans.html",
                                      _ctx(request, user, jobs=jobs, tmap=tmap))


@app.get("/scans/{jid}", response_class=HTMLResponse)
def scan_detail(jid: int, request: Request,
                user: CurrentUser = Depends(current_user), s=Depends(db)):
    job = s.get(ScanJob, jid)
    if not job:
        raise HTTPException(404)
    target = s.get(Target, job.target_id)
    return templates.TemplateResponse(request, "scan.html",
                                      _ctx(request, user, job=job, target=target))


@app.post("/scans/{jid}/cancel")
def scan_cancel(jid: int, user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db)):
    job = s.get(ScanJob, jid)
    if job and job.status == "queued":
        job.status = "canceled"
        s.commit()
    return RedirectResponse("/scans", 303)


# --- findings -----------------------------------------------------------
@app.get("/findings", response_class=HTMLResponse)
def findings(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db),
             severity: str = "", state: str = "", target_id: str = "", engine: str = ""):
    q = select(Issue)
    if severity:
        q = q.where(Issue.severity == severity)
    if state:
        q = q.where(Issue.state == state)
    if target_id:
        q = q.where(Issue.target_id == int(target_id))
    if engine:
        q = q.where(Issue.engine == engine)
    issues = s.scalars(q).all()
    rank = {x.value: x.rank for x in Severity}
    issues.sort(key=lambda i: (rank.get(i.severity, 0), i.last_seen or datetime.min),
                reverse=True)
    tmap = {t.id: t.name for t in s.scalars(select(Target)).all()}
    return templates.TemplateResponse(request, "findings.html", _ctx(
        request, user, issues=issues[:500], tmap=tmap,
        f={"severity": severity, "state": state, "target_id": target_id, "engine": engine},
        severities=[x.value for x in Severity], states=[x.value for x in TriageState]))


@app.post("/findings/{iid}/triage")
def triage(iid: int, request: Request,
           user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db),
           decision: str = Form(...), reason: str = Form(...), days: int = Form(90),
           back: str = Form("")):
    issue = s.get(Issue, iid)
    if not issue:
        raise HTTPException(404)
    mapping = {"fp": TriageState.false_positive, "accept": TriageState.accepted_risk,
               "reopen": TriageState.reopened, "open": TriageState.open}
    st = mapping.get(decision)
    if st is None:
        raise HTTPException(400, "unknown decision")
    until = datetime.now(timezone.utc) + timedelta(days=days) if st == TriageState.accepted_risk else None
    try:
        set_triage(s, issue, st, actor=f"human:{user.username}", reason=reason,
                   accepted_until=until)
        s.commit()
    except ValueError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(back or f"/targets/{issue.target_id}", 303)


# --- reports ------------------------------------------------------------
@app.get("/reports", response_class=HTMLResponse)
def reports(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db)):
    rows = [{"t": t, "summary": report_mod.build_summary(s, t)}
            for t in s.scalars(select(Target)).all()]
    return templates.TemplateResponse(request, "reports.html", _ctx(request, user, rows=rows))


@app.get("/targets/{tid}/report.{fmt}")
def report(tid: int, fmt: str, user: CurrentUser = Depends(current_user), s=Depends(db)):
    t = s.get(Target, tid)
    if not t:
        raise HTTPException(404)
    if fmt == "html":
        return HTMLResponse(report_mod.to_html(s, t))
    if fmt == "json":
        return PlainTextResponse(report_mod.to_json(s, t), media_type="application/json")
    if fmt == "sarif":
        return PlainTextResponse(report_mod.to_sarif(s, t), media_type="application/json")
    raise HTTPException(404)


# --- users --------------------------------------------------------------
@app.get("/users", response_class=HTMLResponse)
def users(request: Request, user: CurrentUser = Depends(require(Role.admin)), s=Depends(db)):
    us = s.scalars(select(User).order_by(User.id)).all()
    return templates.TemplateResponse(request, "users.html",
                                      _ctx(request, user, users=us, roles=[r.value for r in Role]))


@app.post("/users/create")
def user_create(request: Request, user: CurrentUser = Depends(require(Role.admin)), s=Depends(db),
                username: str = Form(...), password: str = Form(...), role: str = Form("viewer")):
    try:
        rbac.create_user(s, username, password, role)
        s.commit()
    except ValueError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse("/users", 303)


@app.post("/users/{uid}/update")
def user_update(uid: int, user: CurrentUser = Depends(require(Role.admin)), s=Depends(db),
                role: str = Form(""), password: str = Form(""), active: str = Form("")):
    u = s.get(User, uid)
    if not u:
        raise HTTPException(404)
    if role:
        u.role = role
    if password:
        u.password_hash = rbac.make_hash(password)
    u.is_active = bool(active)
    s.commit()
    return RedirectResponse("/users", 303)


# --- schedules ----------------------------------------------------------
@app.get("/schedules", response_class=HTMLResponse)
def schedules(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db)):
    schs = s.scalars(select(Schedule).order_by(Schedule.id.desc())).all()
    tmap = {t.id: t.name for t in s.scalars(select(Target)).all()}
    targets = s.scalars(select(Target)).all()
    profiles = s.scalars(select(ScanProfile)).all()
    return templates.TemplateResponse(request, "schedules.html", _ctx(
        request, user, schedules=schs, tmap=tmap, targets=targets, profiles=profiles))


@app.post("/schedules/create")
def schedule_create(request: Request, user: CurrentUser = Depends(require(Role.analyst)),
                    s=Depends(db), target_id: int = Form(...), name: str = Form(""),
                    cron: str = Form("0 2 * * *"), profile_id: str = Form(""),
                    engines: list[str] = Form(default=[])):
    try:
        from croniter import croniter
        croniter(cron)
    except Exception:
        raise HTTPException(400, "invalid cron expression")
    prof = s.get(ScanProfile, int(profile_id)) if profile_id else None
    sch = Schedule(target_id=target_id, name=name, cron=cron,
                   profile_id=(prof.id if prof else None),
                   engines=engines or (prof.engines if prof else ["zap"]),
                   created_by=user.username)
    s.add(sch); s.commit()
    return RedirectResponse("/schedules", 303)


@app.post("/schedules/{sid}/toggle")
def schedule_toggle(sid: int, user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db)):
    sch = s.get(Schedule, sid)
    if sch:
        sch.enabled = not sch.enabled
        s.commit()
    return RedirectResponse("/schedules", 303)


@app.post("/schedules/{sid}/delete")
def schedule_delete(sid: int, user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db)):
    sch = s.get(Schedule, sid)
    if sch:
        s.delete(sch); s.commit()
    return RedirectResponse("/schedules", 303)


# --- scan management ----------------------------------------------------
def _engine_health() -> dict:
    import os, shutil, subprocess
    import httpx as _httpx
    health = {}
    # ZAP
    zap_url = os.environ.get("ZAP_URL", "http://zap:8080")
    zap_key = os.environ.get("ZAP_API_KEY", "changeme")
    try:
        r = _httpx.get(f"{zap_url}/JSON/core/view/version/",
                       params={"apikey": zap_key}, timeout=5)
        health["zap"] = {"ok": r.status_code == 200,
                         "version": r.json().get("version", "?")}
    except Exception as e:  # noqa: BLE001
        health["zap"] = {"ok": False, "version": str(e)[:60]}
    # Nuclei
    if shutil.which("nuclei"):
        try:
            out = subprocess.run(["nuclei", "-version"], capture_output=True,
                                 text=True, timeout=15)
            ver = (out.stderr or out.stdout).strip().splitlines()
            health["nuclei"] = {"ok": True,
                                "version": next((l for l in ver if "." in l), "installed")}
        except Exception as e:  # noqa: BLE001
            health["nuclei"] = {"ok": False, "version": str(e)[:60]}
    else:
        health["nuclei"] = {"ok": False, "version": "not installed"}
    return health


@app.get("/scan-management", response_class=HTMLResponse)
def scan_mgmt(request: Request, user: CurrentUser = Depends(current_user), s=Depends(db)):
    profiles = s.scalars(select(ScanProfile)).all()
    return templates.TemplateResponse(request, "scanmgmt.html", _ctx(
        request, user, health=_engine_health(), profiles=profiles))


@app.post("/scan-management/nuclei-update")
def nuclei_update(user: CurrentUser = Depends(require(Role.analyst))):
    import subprocess
    try:
        out = subprocess.run(["nuclei", "-update-templates"], capture_output=True,
                             text=True, timeout=300)
        msg = (out.stdout + out.stderr)[-300:]
    except Exception as e:  # noqa: BLE001
        msg = str(e)
    return RedirectResponse("/scan-management", 303)


@app.post("/scan-management/profiles/create")
def profile_create(user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db),
                   name: str = Form(...), engines: list[str] = Form(default=[]),
                   nuclei_tags: str = Form(""), full_scan: str = Form("")):
    if s.scalar(select(ScanProfile).where(ScanProfile.name == name)):
        raise HTTPException(400, "profile name exists")
    tags = [t.strip() for t in nuclei_tags.replace(",", "\n").splitlines() if t.strip()]
    s.add(ScanProfile(name=name, engines=engines or ["zap"], nuclei_tags=tags,
                      full_scan=bool(full_scan)))
    s.commit()
    return RedirectResponse("/scan-management", 303)


@app.post("/scan-management/profiles/{pid}/delete")
def profile_delete(pid: int, user: CurrentUser = Depends(require(Role.analyst)), s=Depends(db)):
    p = s.get(ScanProfile, pid)
    if p:
        s.delete(p); s.commit()
    return RedirectResponse("/scan-management", 303)


# --- integrations -------------------------------------------------------
@app.get("/integrations", response_class=HTMLResponse)
def integrations_view(request: Request, user: CurrentUser = Depends(require(Role.admin)), s=Depends(db)):
    ints = s.scalars(select(Integration).order_by(Integration.id)).all()
    flash = request.session.pop("flash", None)
    return templates.TemplateResponse(request, "integrations.html",
                                      _ctx(request, user, integrations=ints, flash=flash))


@app.post("/integrations/save")
def integration_save(request: Request, user: CurrentUser = Depends(require(Role.admin)), s=Depends(db),
                     iid: str = Form(""), kind: str = Form(...), name: str = Form(""),
                     secret: str = Form(""), notify_min_severity: str = Form("high"),
                     enabled: str = Form(""),
                     dd_url: str = Form(""), dd_engagement: str = Form(""),
                     slack_note: str = Form(""),
                     smtp_host: str = Form(""), smtp_port: str = Form("587"),
                     smtp_user: str = Form(""), smtp_from: str = Form(""),
                     smtp_to: str = Form(""), smtp_tls: str = Form("")):
    from ..crypto import encrypt
    integ = s.get(Integration, int(iid)) if iid else Integration(kind=kind)
    if not iid:
        s.add(integ)
    integ.kind = kind
    integ.name = name or kind
    integ.enabled = bool(enabled)
    integ.notify_min_severity = notify_min_severity
    cfg = {}
    if kind == "defectdojo":
        cfg = {"url": dd_url, "engagement_id": dd_engagement}
    elif kind == "smtp":
        cfg = {"host": smtp_host, "port": smtp_port, "user": smtp_user,
               "from": smtp_from, "to": [x.strip() for x in smtp_to.split(",") if x.strip()],
               "use_tls": bool(smtp_tls)}
    integ.config = cfg
    if secret:
        integ.secret_encrypted = encrypt(secret)
    s.commit()
    return RedirectResponse("/integrations", 303)


@app.post("/integrations/{iid}/test")
def integration_test(iid: int, request: Request,
                     user: CurrentUser = Depends(require(Role.admin)), s=Depends(db)):
    integ = s.get(Integration, iid)
    if not integ:
        raise HTTPException(404)
    secret = decrypt(integ.secret_encrypted)
    cfg = integ.config or {}
    if integ.kind == "defectdojo":
        ok, msg = integ_mod.defectdojo_test(cfg.get("url", ""), secret)
    elif integ.kind == "slack":
        ok, msg = integ_mod.slack_test(secret)
    elif integ.kind == "smtp":
        to = cfg.get("to") or []
        ok, msg = integ_mod.smtp_send(cfg.get("host", ""), int(cfg.get("port", 587)),
                                      cfg.get("user", ""), secret, cfg.get("from", ""),
                                      to or [cfg.get("from", "")], "dast-triage test",
                                      "Test message from dast-triage.",
                                      use_tls=bool(cfg.get("use_tls", True)))
    else:
        ok, msg = False, "unknown kind"
    request.session["flash"] = f"{integ.name}: {'OK' if ok else 'FAILED'} — {msg}"
    return RedirectResponse("/integrations", 303)


@app.post("/integrations/{iid}/delete")
def integration_delete(iid: int, user: CurrentUser = Depends(require(Role.admin)), s=Depends(db)):
    integ = s.get(Integration, iid)
    if integ:
        s.delete(integ); s.commit()
    return RedirectResponse("/integrations", 303)


@app.get("/healthz", response_class=PlainTextResponse)
def healthz():
    return "ok"
