"""Authenticated-scan login helper.

For form-based auth we pre-authenticate with httpx: fetch the login page,
carry forward every hidden field (so CSRF / anti-forgery tokens like DVWA's
`user_token` are included), submit the credentials, and return the resulting
session cookies. Those cookies are then injected as a `Cookie:` header into
both scan engines, so ZAP and Nuclei crawl the app logged in.

This handles the common cookie-session + hidden-token login (DVWA, many PHP /
Rails / Django apps). It does not solve JS-rendered logins or MFA — those need
a browser-driven flow, a later enhancement.
"""
from __future__ import annotations

import re
from html.parser import HTMLParser
from urllib.parse import urljoin

import httpx


class _HiddenInputs(HTMLParser):
    def __init__(self):
        super().__init__()
        self.fields: dict[str, str] = {}
        self.form_action: str | None = None
        self._in_target_form = True  # take the first form on the page

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "form" and self.form_action is None:
            self.form_action = a.get("action")
        if tag == "input":
            name = a.get("name")
            if not name:
                return
            itype = (a.get("type") or "text").lower()
            if itype == "hidden":
                self.fields[name] = a.get("value", "")


def form_login(
    login_url: str,
    username: str,
    password: str,
    username_field: str = "username",
    password_field: str = "password",
    extra_fields: dict[str, str] | None = None,
    logged_in_regex: str | None = None,
    timeout: float = 20.0,
) -> tuple[dict[str, str], str]:
    """Return (cookies, message). cookies is empty on failure."""
    username_field = username_field or "username"
    password_field = password_field or "password"
    with httpx.Client(follow_redirects=True, timeout=timeout) as client:
        try:
            page = client.get(login_url)
        except httpx.HTTPError as e:
            return {}, f"could not fetch login page: {e}"

        parser = _HiddenInputs()
        try:
            parser.feed(page.text)
        except Exception:
            pass

        data = dict(parser.fields)
        data[username_field] = username
        data[password_field] = password
        if extra_fields:
            data.update(extra_fields)

        action = parser.form_action
        post_url = urljoin(login_url, action) if action else login_url
        try:
            resp = client.post(post_url, data=data)
        except httpx.HTTPError as e:
            return {}, f"login POST failed: {e}"

        cookies = {c.name: c.value for c in client.cookies.jar}
        if logged_in_regex:
            body = resp.text
            if not re.search(logged_in_regex, body):
                # still return cookies, but flag the uncertainty
                return cookies, ("logged-in indicator not found; "
                                 "proceeding with captured session anyway")
        if not cookies:
            return {}, "login produced no session cookies"
        return cookies, f"authenticated; captured {len(cookies)} cookie(s)"


def cookie_header(cookies: dict[str, str]) -> str:
    return "; ".join(f"{k}={v}" for k, v in cookies.items())
