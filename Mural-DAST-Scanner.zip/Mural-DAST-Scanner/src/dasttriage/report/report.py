"""Report generation: clean HTML, JSON and SARIF.

The clean report is the deliverable. Rules:
  * Body shows only live issues (new/open/reopened).
  * Accepted risks go in an appendix with their expiry dates (visible, not
    hidden) so an auditor sees what was acknowledged and until when.
  * False positives are NOT in the body, but their count is shown with a note,
    so suppression is transparent rather than silent.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from jinja2 import Environment, FileSystemLoader, select_autoescape
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import Issue, Target
from ..models import Severity, TriageState

_TEMPLATES = Path(__file__).parent / "templates"

_SARIF_LEVEL = {
    Severity.info: "note", Severity.low: "note",
    Severity.medium: "warning", Severity.high: "error",
    Severity.critical: "error",
}


def _issues(session: Session, target: Target) -> list[Issue]:
    return session.scalars(
        select(Issue).where(Issue.target_id == target.id)
    ).all()


def _bucket(issues: list[Issue]) -> dict[str, list[Issue]]:
    live, accepted, fp, fixed = [], [], [], []
    for i in issues:
        st = i.state
        if st in (TriageState.new.value, TriageState.open.value,
                  TriageState.reopened.value):
            live.append(i)
        elif st == TriageState.accepted_risk.value:
            accepted.append(i)
        elif st == TriageState.false_positive.value:
            fp.append(i)
        elif st == TriageState.fixed.value:
            fixed.append(i)
    sev_rank = {s.value: s.rank for s in Severity}
    live.sort(key=lambda i: sev_rank.get(i.severity, 0), reverse=True)
    return {"live": live, "accepted": accepted, "fp": fp, "fixed": fixed}


def build_summary(session: Session, target: Target) -> dict:
    issues = _issues(session, target)
    b = _bucket(issues)
    counts = {s.value: 0 for s in Severity}
    for i in b["live"]:
        counts[i.severity] = counts.get(i.severity, 0) + 1
    return {
        "target": target.name,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "counts_by_severity": counts,
        "live_total": len(b["live"]),
        "accepted_total": len(b["accepted"]),
        "false_positive_total": len(b["fp"]),
        "fixed_total": len(b["fixed"]),
        "buckets": b,
    }


def to_json(session: Session, target: Target) -> str:
    s = build_summary(session, target)

    def issue_dict(i: Issue) -> dict:
        return {
            "id": i.id, "fingerprint": i.fingerprint, "name": i.name,
            "severity": i.severity, "state": i.state, "engine": i.engine,
            "url": i.url, "param": i.param, "cwe": i.cwe,
            "times_seen": i.times_seen,
            "first_seen": i.first_seen.isoformat() if i.first_seen else None,
            "last_seen": i.last_seen.isoformat() if i.last_seen else None,
            "accepted_until": i.accepted_until.isoformat() if i.accepted_until else None,
            "triage_reason": i.triage_reason,
            "ai_verdict": i.ai_verdict, "ai_confidence": i.ai_confidence,
        }

    payload = {
        "target": s["target"],
        "generated_at": s["generated_at"],
        "summary": {k: s[k] for k in (
            "counts_by_severity", "live_total", "accepted_total",
            "false_positive_total", "fixed_total")},
        "findings": [issue_dict(i) for i in s["buckets"]["live"]],
        "accepted_risks": [issue_dict(i) for i in s["buckets"]["accepted"]],
    }
    return json.dumps(payload, indent=2)


def to_sarif(session: Session, target: Target) -> str:
    """SARIF 2.1.0 so results flow into GitHub/GitLab code-scanning."""
    b = _bucket(_issues(session, target))
    rules, results = {}, []
    for i in b["live"]:
        rule_id = f"{i.engine}/{i.engine_rule_id}"
        rules.setdefault(rule_id, {
            "id": rule_id,
            "name": i.name,
            "shortDescription": {"text": i.name},
            "properties": {"security-severity": str(
                {"info": "0.0", "low": "3.0", "medium": "5.5",
                 "high": "8.0", "critical": "9.5"}.get(i.severity, "0.0"))},
        })
        results.append({
            "ruleId": rule_id,
            "level": _SARIF_LEVEL.get(Severity(i.severity), "warning"),
            "message": {"text": f"{i.name} at {i.url}"
                        + (f" (param {i.param})" if i.param else "")},
            "locations": [{"physicalLocation": {
                "artifactLocation": {"uri": i.url}}}],
            "partialFingerprints": {"dastTriage/v1": i.fingerprint},
        })
    sarif = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [{
            "tool": {"driver": {
                "name": "dast-triage",
                "informationUri": "https://example.invalid/dast-triage",
                "version": "0.1.0",
                "rules": list(rules.values()),
            }},
            "results": results,
        }],
    }
    return json.dumps(sarif, indent=2)


def to_html(session: Session, target: Target) -> str:
    s = build_summary(session, target)
    env = Environment(
        loader=FileSystemLoader(str(_TEMPLATES)),
        autoescape=select_autoescape(["html"]),
    )
    tpl = env.get_template("report.html.j2")
    return tpl.render(**s)


def write_reports(session: Session, target: Target, out_dir: str | Path) -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, fn in (("report.html", to_html), ("report.json", to_json),
                     ("report.sarif", to_sarif)):
        p = out / name
        p.write_text(fn(session, target))
        paths[name] = str(p)
    return paths
