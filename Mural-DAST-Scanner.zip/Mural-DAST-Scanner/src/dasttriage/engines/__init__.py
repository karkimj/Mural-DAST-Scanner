"""Engine registry."""
from __future__ import annotations

from .base import Engine
from .nuclei import NucleiEngine
from .zap import ZapEngine

_REGISTRY: dict[str, type[Engine]] = {
    "zap": ZapEngine,
    "nuclei": NucleiEngine,
}


def get_engine(name: str, **kwargs) -> Engine:
    try:
        return _REGISTRY[name.lower()](**kwargs)
    except KeyError:
        raise KeyError(f"unknown engine {name!r}; known: {sorted(_REGISTRY)}")


def available() -> list[str]:
    return sorted(_REGISTRY)


__all__ = ["Engine", "ZapEngine", "NucleiEngine", "get_engine", "available"]
