"""Users, roles and DB-backed authentication.

Roles (ascending privilege):
  viewer  - read findings/reports
  analyst - + manage targets, run scans, triage
  admin   - + manage users, integrations, settings

Password hashing reuses the PBKDF2 helpers from web.auth.
"""
from __future__ import annotations

import enum

from sqlalchemy import select
from sqlalchemy.orm import Session

from .db import ScanProfile, User
from .models import utcnow
from .web.auth import make_hash
from .web.auth import _decode, _ALGO  # noqa: F401  (reuse verify primitives)

import hashlib
import hmac


class Role(str, enum.Enum):
    viewer = "viewer"
    analyst = "analyst"
    admin = "admin"

    @property
    def level(self) -> int:
        return {"viewer": 0, "analyst": 1, "admin": 2}[self.value]


def role_at_least(role: str, minimum: Role) -> bool:
    try:
        return Role(role).level >= minimum.level
    except ValueError:
        return False


def verify_password(encoded: str, password: str) -> bool:
    try:
        iters, salt, digest = _decode(encoded)
    except Exception:
        return False
    cand = hashlib.pbkdf2_hmac(_ALGO, password.encode("utf-8"), salt, iters)
    return hmac.compare_digest(cand, digest)


def create_user(session: Session, username: str, password: str, role: str = "viewer") -> User:
    if session.scalar(select(User).where(User.username == username)):
        raise ValueError(f"user {username!r} already exists")
    if role not in (r.value for r in Role):
        raise ValueError(f"invalid role {role!r}")
    u = User(username=username, password_hash=make_hash(password), role=role)
    session.add(u)
    session.flush()
    return u


def authenticate(session: Session, username: str, password: str) -> User | None:
    u = session.scalar(select(User).where(User.username == username))
    if not u or not u.is_active:
        return None
    if not verify_password(u.password_hash, password):
        return None
    u.last_login = utcnow()
    session.commit()
    return u


def set_password(session: Session, user: User, password: str) -> None:
    user.password_hash = make_hash(password)
    session.commit()


def bootstrap(session: Session) -> None:
    """Create the first admin and default scan profiles if the DB is empty."""
    import os

    if not session.scalar(select(User).limit(1)):
        admin_user = os.environ.get("DAST_WEB_USER", "mural")
        admin_pass = os.environ.get("DAST_WEB_PASSWORD", "Ansrn17!!")
        create_user(session, admin_user, admin_pass, role="admin")

    if not session.scalar(select(ScanProfile).limit(1)):
        session.add_all([
            ScanProfile(name="quick", description="Fast pass: Nuclei + ZAP spider only",
                        engines=["nuclei"], nuclei_tags=["cve", "misconfig", "exposure"],
                        full_scan=False),
            ScanProfile(name="full", description="ZAP active scan + Nuclei",
                        engines=["zap", "nuclei"], nuclei_tags=[], full_scan=True),
        ])
    session.commit()
