from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from dasttriage import service
from dasttriage.db import Issue, init_db, make_engine, make_session
from dasttriage.engines import get_engine
from dasttriage.lifecycle import set_triage
from dasttriage.models import TriageState

FIX = Path(__file__).parent / "fixtures"


@pytest.fixture()
def session():
    eng = make_engine("sqlite:///:memory:")
    init_db(eng)
    s = make_session(eng)()
    yield s
    s.close()


def _import(session, fixture, full=True):
    return service.import_file(session, "staging", "zap", FIX / fixture,
                               full_scan=full)


def test_import_creates_issues(session):
    res = _import(session, "zap_sample.json")
    assert res["ingested"] == 3
    assert res["new_issues"] == 3
    issues = session.query(Issue).all()
    assert len(issues) == 3
    assert all(i.state == TriageState.new.value for i in issues)


def test_false_positive_carries_forward(session):
    _import(session, "zap_sample.json")
    # mark the missing-header issue a false positive
    hdr = session.query(Issue).filter(Issue.engine_rule_id == "10021").one()
    set_triage(session, hdr, TriageState.false_positive,
               actor="human:test", reason="informational only")
    session.commit()

    # rescan: header finding is gone, SQLi reappears with a different id.
    res = _import(session, "zap_sample_rescan.json")
    assert res["new_issues"] == 0  # everything matched by fingerprint

    hdr = session.query(Issue).filter(Issue.engine_rule_id == "10021").one()
    # FP decision must survive, and must NOT be auto-closed as fixed.
    assert hdr.state == TriageState.false_positive.value


def test_absent_issue_marked_fixed_then_reopened(session):
    _import(session, "zap_sample.json")
    # rescan without the missing-header finding -> it should become fixed
    _import(session, "zap_sample_rescan.json")
    hdr = session.query(Issue).filter(Issue.engine_rule_id == "10021").one()
    assert hdr.state == TriageState.fixed.value

    # it comes back in a later scan -> reopened, not new, not fixed
    _import(session, "zap_sample.json")
    hdr = session.query(Issue).filter(Issue.engine_rule_id == "10021").one()
    assert hdr.state == TriageState.reopened.value


def test_accepted_risk_requires_expiry(session):
    _import(session, "zap_sample.json")
    issue = session.query(Issue).first()
    with pytest.raises(ValueError):
        set_triage(session, issue, TriageState.accepted_risk,
                   actor="h", reason="ok", accepted_until=None)


def test_accepted_risk_expires_and_reopens(session):
    _import(session, "zap_sample.json")
    issue = session.query(Issue).filter(Issue.engine_rule_id == "40018").one()
    past = datetime.now(timezone.utc) - timedelta(days=1)
    set_triage(session, issue, TriageState.accepted_risk,
               actor="human:test", reason="risk accepted by owner",
               accepted_until=past)
    session.commit()

    # a new scan triggers expiry sweep
    _import(session, "zap_sample.json")
    issue = session.query(Issue).filter(Issue.engine_rule_id == "40018").one()
    assert issue.state == TriageState.open.value


def test_full_scan_does_not_close_other_engines_findings(session):
    # ZAP full scan + Nuclei import, then a ZAP-only full rescan.
    _import(session, "zap_sample.json")
    service.import_file(session, "staging", "nuclei",
                        FIX / "nuclei_sample.jsonl", full_scan=False)
    # ZAP-only full rescan (drops the header finding)
    _import(session, "zap_sample_rescan.json")

    # Nuclei findings must stay active, not be collateral-closed by ZAP's scan.
    log4j = session.query(Issue).filter(Issue.engine == "nuclei",
                                        Issue.engine_rule_id == "CVE-2021-44228").one()
    assert log4j.state in (TriageState.new.value, TriageState.open.value,
                           TriageState.reopened.value)
    # ZAP's own absent finding is still correctly closed
    hdr = session.query(Issue).filter(Issue.engine_rule_id == "10021").one()
    assert hdr.state == TriageState.fixed.value


def test_triage_requires_reason(session):
    _import(session, "zap_sample.json")
    issue = session.query(Issue).first()
    with pytest.raises(ValueError):
        set_triage(session, issue, TriageState.false_positive,
                   actor="h", reason="  ")
