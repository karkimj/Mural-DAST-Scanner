"""Command-line interface.

    dast import   <target> <engine> <file>     # ingest saved scanner output
    dast scan     <scope.yaml> <url> [engines]  # drive a live scan
    dast findings <target> [--state ...]        # list issues
    dast triage   <issue_id> <decision> ...     # mark fp / accept risk / reopen
    dast report   <target> [--out dir]          # clean HTML + JSON + SARIF
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import typer
from sqlalchemy import select

from . import report as report_mod
from . import service
from .config import ScopeConfig
from .db import Issue, Target, init_db, make_engine, make_session
from .lifecycle import set_triage
from .models import TriageState

app = typer.Typer(add_completion=False, help="Portable DAST triage tool")


def _session():
    eng = make_engine()
    init_db(eng)
    return make_session(eng)()


def _find_target(session, name: str) -> Target:
    t = session.scalar(select(Target).where(Target.name == name))
    if t is None:
        typer.secho(f"no such target: {name}", fg="red", err=True)
        raise typer.Exit(2)
    return t


@app.command("import")
def import_cmd(
    target: str,
    engine: str = typer.Argument(..., help="zap | nuclei"),
    file: Path = typer.Argument(..., exists=True, readable=True),
    full: bool = typer.Option(False, "--full",
        help="treat as a full scan (absent issues get marked fixed)"),
):
    """Ingest a saved ZAP/Nuclei report file."""
    s = _session()
    res = service.import_file(s, target, engine, file, full_scan=full)
    typer.echo(_fmt(res))


@app.command("scan")
def scan_cmd(
    scope_file: Path = typer.Argument(..., exists=True),
    url: str = typer.Argument(...),
    engines: str = typer.Option("zap,nuclei", help="comma-separated"),
    zap_url: str = typer.Option("http://localhost:8080"),
    zap_key: str = typer.Option("", help="ZAP API key"),
):
    """Drive a live scan (requires reachable engines)."""
    scope = ScopeConfig.load(scope_file)
    s = _session()
    kwargs = {"zap": {"base_url": zap_url, "api_key": zap_key}}
    res = service.live_scan(s, url, scope, engines.split(","), **kwargs)
    typer.echo(_fmt(res))


@app.command("findings")
def findings_cmd(
    target: str,
    state: str = typer.Option("", help="filter by state (comma-separated)"),
):
    """List issues for a target."""
    s = _session()
    t = _find_target(s, target)
    q = select(Issue).where(Issue.target_id == t.id)
    if state:
        q = q.where(Issue.state.in_([x.strip() for x in state.split(",")]))
    rows = s.scalars(q).all()
    rows.sort(key=lambda i: (i.severity, i.last_seen or datetime.min), reverse=True)
    if not rows:
        typer.echo("(no matching findings)")
        return
    for i in rows:
        line = (f"#{i.id:<4} [{i.severity:<8}] {i.state:<14} "
                f"{i.name[:48]:<48} {i.url[:50]}")
        typer.echo(line)
    typer.echo(f"\n{len(rows)} issue(s)")


@app.command("triage")
def triage_cmd(
    issue_id: int,
    decision: str = typer.Argument(..., help="fp | accept | reopen | open"),
    reason: str = typer.Option(..., "--reason", "-r", help="required justification"),
    actor: str = typer.Option("human:cli", "--actor"),
    days: int = typer.Option(90, "--days",
        help="for 'accept': days until the risk acceptance expires"),
):
    """Apply a triage decision to one issue."""
    s = _session()
    issue = s.get(Issue, issue_id)
    if issue is None:
        typer.secho(f"no such issue #{issue_id}", fg="red", err=True)
        raise typer.Exit(2)

    mapping = {
        "fp": TriageState.false_positive,
        "false_positive": TriageState.false_positive,
        "accept": TriageState.accepted_risk,
        "accepted_risk": TriageState.accepted_risk,
        "reopen": TriageState.reopened,
        "open": TriageState.open,
    }
    state = mapping.get(decision)
    if state is None:
        typer.secho(f"unknown decision {decision!r}; use {sorted(mapping)}",
                    fg="red", err=True)
        raise typer.Exit(2)

    until = None
    if state == TriageState.accepted_risk:
        until = datetime.now(timezone.utc) + timedelta(days=days)
    set_triage(s, issue, state, actor=actor, reason=reason, accepted_until=until)
    s.commit()
    msg = f"#{issue_id} -> {state.value}"
    if until:
        msg += f" (expires {until.date()})"
    typer.secho(msg, fg="green")


@app.command("report")
def report_cmd(
    target: str,
    out: Path = typer.Option(Path("reports"), "--out", "-o"),
):
    """Write the clean report (HTML, JSON, SARIF)."""
    s = _session()
    t = _find_target(s, target)
    paths = report_mod.write_reports(s, t, out)
    for name, p in paths.items():
        typer.echo(f"{name:<14} {p}")


@app.command("serve")
def serve_cmd(
    host: str = typer.Option("0.0.0.0", help="bind address"),
    port: int = typer.Option(8000),
    reload: bool = typer.Option(False, help="dev autoreload"),
):
    """Run the password-protected web UI."""
    try:
        import uvicorn
    except ImportError:
        typer.secho("web extras not installed: pip install 'dast-triage[web]'",
                    fg="red", err=True)
        raise typer.Exit(1)
    typer.echo(f"serving dast-triage web UI on http://{host}:{port}")
    uvicorn.run("dasttriage.web.app:app", host=host, port=port, reload=reload)


def _fmt(res: dict) -> str:
    return " ".join(f"{k}={v}" for k, v in res.items())


if __name__ == "__main__":
    app()
