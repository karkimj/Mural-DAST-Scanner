"""OWASP ZAP adapter.

Two paths:
  * parse() reads a ZAP JSON report (the `traditional-json` / core alerts
    export) offline. This is the shape used by `zap.sh -quickout report.json`
    and by the ZAP API `/JSON/core/view/alerts/`.
  * scan() drives a ZAP daemon over its REST API: spider -> ajax spider ->
    active scan -> pull alerts. Requires a reachable ZAP (sidecar container).

ZAP risk/confidence are integer-coded in the API; we map them explicitly.
"""
from __future__ import annotations

import json
import time

import httpx

from ..config import ScopeConfig
from ..models import Confidence, Evidence, RawFinding, Severity
from .base import Engine

_RISK_MAP = {
    "0": Severity.info, "1": Severity.low, "2": Severity.medium, "3": Severity.high,
    "informational": Severity.info, "low": Severity.low,
    "medium": Severity.medium, "high": Severity.high,
}
_CONF_MAP = {
    "0": Confidence.low, "1": Confidence.low, "2": Confidence.medium,
    "3": Confidence.high, "4": Confidence.confirmed,
    "false positive": Confidence.low,
}


def _sev(raw) -> Severity:
    return _RISK_MAP.get(str(raw).strip().lower(), Severity.info)


def _conf(raw) -> Confidence:
    return _CONF_MAP.get(str(raw).strip().lower(), Confidence.medium)


class ZapEngine(Engine):
    name = "zap"

    def __init__(self, base_url: str = "http://localhost:8080", api_key: str = ""):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def _alert(self, a: dict) -> RawFinding:
        cwe = a.get("cweid")
        try:
            cwe = int(cwe) if cwe not in (None, "", "-1") else None
        except (ValueError, TypeError):
            cwe = None
        url = a.get("url", "")
        return RawFinding(
            engine=self.name,
            engine_rule_id=str(a.get("pluginId") or a.get("pluginid") or "unknown"),
            name=a.get("alert") or a.get("name") or "ZAP alert",
            severity=_sev(a.get("risk", a.get("riskcode", "0"))),
            confidence=_conf(a.get("confidence", "2")),
            url=url,
            method=a.get("method", "GET") or "GET",
            param=a.get("param") or None,
            cwe=cwe,
            description=a.get("description", "") or "",
            remediation=a.get("solution", "") or "",
            references=[r for r in (a.get("reference", "") or "").split("\n") if r],
            evidence=Evidence(
                url=url,
                method=a.get("method", "GET") or "GET",
                param=a.get("param") or None,
                attack=a.get("attack") or None,
                response_snippet=(a.get("evidence") or "") or None,
                other={"messageId": str(a.get("messageId", ""))},
            ),
            raw=a,
        )

    def parse(self, payload: str | bytes | dict) -> list[RawFinding]:
        if isinstance(payload, (str, bytes)):
            payload = json.loads(payload)
        alerts: list[dict] = []
        if isinstance(payload, dict):
            if "alerts" in payload:                 # core/view/alerts
                alerts = payload["alerts"]
            elif "site" in payload:                  # traditional-json report
                sites = payload["site"]
                if isinstance(sites, dict):
                    sites = [sites]
                for s in sites:
                    alerts.extend(s.get("alerts", []))
            else:
                alerts = [payload]
        elif isinstance(payload, list):
            alerts = payload
        return [self._alert(a) for a in alerts]

    # ---- live daemon driving ----
    def _get(self, client: httpx.Client, path: str, **params) -> dict:
        params["apikey"] = self.api_key
        r = client.get(f"{self.base_url}{path}", params=params, timeout=30)
        r.raise_for_status()
        return r.json()

    def _wait(self, client: httpx.Client, status_path: str, key: str = "status") -> None:
        while True:
            st = self._get(client, status_path).get(key, "100")
            if str(st) == "100":
                return
            time.sleep(2)

    def _add_header_rules(self, client: httpx.Client, headers: dict[str, str]) -> None:
        """Inject auth headers on every request via ZAP replacer rules."""
        for name, value in headers.items():
            try:
                self._get(
                    client, "/JSON/replacer/action/addRule/",
                    description=f"auth-{name}", enabled="true",
                    matchType="REQ_HEADER", matchRegex="false",
                    matchString=name, replacement=value,
                )
            except httpx.HTTPError:
                pass

    def scan(self, target: str, scope: ScopeConfig,
             headers: dict[str, str] | None = None,
             active: bool = True) -> list[RawFinding]:
        scope.assert_in_scope(target)
        with httpx.Client() as client:
            if headers:
                self._add_header_rules(client, headers)
            self._get(client, "/JSON/spider/action/scan/", url=target,
                      recurse="true")
            self._wait(client, "/JSON/spider/view/status/")
            if active:
                try:
                    self._get(client, "/JSON/ascan/action/scan/", url=target,
                              recurse="true")
                    self._wait(client, "/JSON/ascan/view/status/")
                except httpx.HTTPError:
                    pass
            alerts = self._get(client, "/JSON/core/view/alerts/", baseurl=target)
        return self.parse(alerts)
