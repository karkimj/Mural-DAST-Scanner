"""Web UI package for dast-triage. Import the app from dasttriage.web.app."""
