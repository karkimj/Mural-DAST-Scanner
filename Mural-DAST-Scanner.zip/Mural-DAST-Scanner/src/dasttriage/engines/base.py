"""Engine adapter interface.

An adapter turns a concrete scanner into a stream of normalized RawFindings.
Two capabilities, kept separate so file-import works without a live scanner:

  * parse(payload) -> list[RawFinding]   # pure, offline, always available
  * scan(target, scope) -> list[RawFinding]  # drives the live tool

Keeping `parse` pure means we can unit-test normalization against saved sample
output and re-import past scans without re-running anything.
"""
from __future__ import annotations

import abc

from ..config import ScopeConfig
from ..fingerprint import compute
from ..models import RawFinding
from .redact import redact_finding


class Engine(abc.ABC):
    name: str = "base"

    @abc.abstractmethod
    def parse(self, payload: str | bytes | dict) -> list[RawFinding]:
        """Normalize raw engine output into findings (no fingerprint yet)."""

    def scan(self, target: str, scope: ScopeConfig) -> list[RawFinding]:
        raise NotImplementedError(
            f"{self.name} adapter cannot drive a live scan in this build; "
            f"use `import` with saved output instead"
        )

    def finalize(self, findings: list[RawFinding]) -> list[RawFinding]:
        """Redact evidence, then stamp fingerprints. Call after parse/scan."""
        out = []
        for f in findings:
            f = redact_finding(f)
            f.with_fingerprint(compute(f))
            out.append(f)
        return out
