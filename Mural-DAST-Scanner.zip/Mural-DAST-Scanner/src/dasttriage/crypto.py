"""Encryption of secrets at rest (target credentials, integration tokens).

Uses Fernet (AES-128-CBC + HMAC). The key comes from DAST_FERNET_KEY; if unset,
a key is generated at startup and the operator is warned — in that mode secrets
do not survive a restart, which is fine for dev but must be fixed for prod by
setting a stable key (generate one with `python -m dasttriage.crypto`).
"""
from __future__ import annotations

import os
import sys

from cryptography.fernet import Fernet, InvalidToken

_WARNED = False


def _key() -> bytes:
    global _WARNED
    env = os.environ.get("DAST_FERNET_KEY")
    if env:
        return env.encode() if not isinstance(env, bytes) else env
    if not _WARNED:
        sys.stderr.write(
            "WARNING: DAST_FERNET_KEY not set; using an ephemeral key. "
            "Stored secrets will NOT survive a restart. "
            "Generate one with `python -m dasttriage.crypto` and set it.\n"
        )
        _WARNED = True
    # cache a process-lifetime key so encrypt/decrypt are consistent within a run
    global _EPHEMERAL
    try:
        return _EPHEMERAL
    except NameError:
        _EPHEMERAL = Fernet.generate_key()
        return _EPHEMERAL


def encrypt(plaintext: str) -> str:
    if plaintext is None:
        return ""
    return Fernet(_key()).encrypt(plaintext.encode("utf-8")).decode("ascii")


def decrypt(token: str) -> str:
    if not token:
        return ""
    try:
        return Fernet(_key()).decrypt(token.encode("ascii")).decode("utf-8")
    except InvalidToken:
        # key rotated or secret written under a different key
        return ""


if __name__ == "__main__":
    print(Fernet.generate_key().decode())
