"""In-process scan worker.

A single background daemon thread drains the ScanJob queue FIFO (concurrency 1
for v1) and runs the selected engines against the target, injecting any
configured auth headers, then ingests findings through the existing service
layer. Runs inside the web container, which is on the scan network and has the
Nuclei binary and reachability to ZAP.
"""
from __future__ import annotations

import base64
import os
import threading
import time
import traceback
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import authflow, integrations, lifecycle
from .config import ScopeConfig, VerifierPolicy
from .crypto import decrypt
from .db import (
    Credential, Integration, Issue, ScanJob, ScanProfile, ScanRun,
    Schedule, Target,
)
from .engines import get_engine
from .models import Severity, TriageState, utcnow

ZAP_URL = os.environ.get("ZAP_URL", "http://zap:8080")
ZAP_KEY = os.environ.get("ZAP_API_KEY", "changeme")

_stop = threading.Event()
_thread: threading.Thread | None = None


# ---- helpers -------------------------------------------------------------

def scope_for(target: Target) -> ScopeConfig:
    include = list(target.include_hosts or [])
    if not include:
        # derive from base URLs / name so a scan is always bounded
        from urllib.parse import urlsplit
        for u in (target.base_urls or []):
            h = urlsplit(u if "://" in u else f"http://{u}").hostname
            if h:
                include.append(h)
        include = include or [target.name]
    return ScopeConfig(
        name=target.name,
        include_hosts=include,
        exclude_hosts=list(target.exclude_hosts or []),
        exclude_paths=list(target.exclude_paths or []),
        max_rps=target.max_rps or 10.0,
        verifier=VerifierPolicy(
            allow_active_exploit=target.allow_active_exploit,
            sqlmap_level=target.sqlmap_level,
            sqlmap_risk=target.sqlmap_risk,
        ),
    )


def auth_headers_for(session: Session, target: Target) -> dict[str, str]:
    """Build HTTP auth headers from the target's method + stored credential.

    Covers basic / bearer / custom-header / cookie. Form login is handled
    separately (not in v1) and returns no header here.
    """
    method = (target.auth_method or "none").lower()
    if method in ("none", "form", ""):
        return {}
    cred = session.scalar(
        select(Credential).where(Credential.target_id == target.id)
        .order_by(Credential.id.desc())
    )
    secret = decrypt(cred.secret_encrypted) if cred else ""
    user = cred.username if cred else ""
    if method == "basic":
        raw = f"{user}:{secret}".encode()
        return {"Authorization": "Basic " + base64.b64encode(raw).decode()}
    if method == "bearer":
        return {"Authorization": f"Bearer {secret}"}
    if method == "header":
        name = target.auth_header_name or "Authorization"
        return {name: secret}
    if method == "cookie":
        return {"Cookie": secret}
    if method == "form":
        if not target.auth_login_url:
            return {}
        cookies, _msg = authflow.form_login(
            target.auth_login_url, user, secret,
            username_field=target.auth_username_field or "username",
            password_field=target.auth_password_field or "password",
            logged_in_regex=target.auth_logged_in_regex or None,
        )
        if cookies:
            return {"Cookie": authflow.cookie_header(cookies)}
        return {}
    return {}


def _targets_url(target: Target) -> str:
    if target.base_urls:
        return target.base_urls[0]
    return f"http://{target.name}"


# ---- the job runner ------------------------------------------------------

def run_job(session: Session, job: ScanJob) -> None:
    target = session.get(Target, job.target_id)
    if target is None:
        job.status = "failed"; job.error = "target deleted"; job.finished_at = utcnow()
        session.commit(); return
    if not target.authorized:
        job.status = "failed"
        job.error = "target not marked authorized for scanning"
        job.finished_at = utcnow(); session.commit(); return

    engines = list(job.engines or [])
    profile = session.get(ScanProfile, job.profile_id) if job.profile_id else None
    tags = list(profile.nuclei_tags) if (profile and profile.nuclei_tags) else []
    scope = scope_for(target)
    url = _targets_url(target)
    headers = auth_headers_for(session, target)
    loglines: list[str] = []

    def log(m: str):
        loglines.append(f"{datetime.now(timezone.utc).strftime('%H:%M:%S')} {m}")
        job.log = "\n".join(loglines[-200:]); session.commit()

    job.status = "running"; job.started_at = utcnow(); session.commit()
    log(f"scan start target={target.name} url={url} engines={engines} auth={target.auth_method}")

    all_findings = []
    try:
        for name in engines:
            log(f"engine {name} starting")
            if name == "zap":
                eng = get_engine("zap", base_url=ZAP_URL, api_key=ZAP_KEY)
                raw = eng.scan(url, scope, headers=headers,
                               active=(profile.full_scan if profile else True))
            elif name == "nuclei":
                eng = get_engine("nuclei")
                raw = eng.scan(url, scope, headers=headers, tags=tags)
            else:
                log(f"unknown engine {name}, skipping"); continue
            done = eng.finalize(raw)
            all_findings.extend(done)
            log(f"engine {name} -> {len(done)} findings")

        from . import service
        res = service.run_scan(session, target.name, all_findings, engines,
                               full_scan=job.full_scan)
        job.result = res
        # link the ScanRun we just created (latest for this target)
        run = session.scalar(
            select(ScanRun).where(ScanRun.target_id == target.id)
            .order_by(ScanRun.id.desc())
        )
        job.scan_run_id = run.id if run else None
        job.status = "completed"; job.finished_at = utcnow()
        log(f"done ingested={res['ingested']} new={res['new_issues']} "
            f"closed={res['closed_as_fixed']}")
        session.commit()
        try:
            notify_after_scan(session, target)
        except Exception as ne:  # noqa: BLE001
            log(f"notify error: {ne}")
    except Exception as e:  # noqa: BLE001
        job.status = "failed"
        job.error = f"{type(e).__name__}: {e}"
        job.finished_at = utcnow()
        log("ERROR " + job.error)
        log(traceback.format_exc().splitlines()[-1])
        session.commit()


# ---- notifications -------------------------------------------------------

def notify_after_scan(session: Session, target: Target) -> None:
    """On scan completion, notify enabled integrations about open findings."""
    live = (TriageState.new.value, TriageState.open.value, TriageState.reopened.value)
    open_issues = session.scalars(
        select(Issue).where(Issue.target_id == target.id, Issue.state.in_(live))
    ).all()
    ints = session.scalars(
        select(Integration).where(Integration.enabled.is_(True))
    ).all()
    if not ints:
        return

    from . import report as report_mod
    for integ in ints:
        minsev = integ.notify_min_severity or "high"
        hits = [i for i in open_issues if integrations.min_sev_ok(i.severity, minsev)]
        cfg = integ.config or {}
        secret = decrypt(integ.secret_encrypted)
        try:
            if integ.kind == "defectdojo" and cfg.get("engagement_id"):
                sarif = report_mod.to_sarif(session, target)
                integrations.defectdojo_push(
                    cfg.get("url", ""), secret, int(cfg["engagement_id"]),
                    sarif, f"{target.name}")
            elif integ.kind == "slack" and hits:
                lines = "\n".join(f"• {i.severity.upper()} {i.name} — {i.url}"
                                  for i in hits[:10])
                integrations.slack_send(
                    secret,
                    f"*dast-triage* — {target.name}: {len(hits)} open "
                    f"{minsev}+ finding(s)\n{lines}")
            elif integ.kind == "smtp" and hits:
                to = cfg.get("to") or []
                if isinstance(to, str):
                    to = [to]
                if to:
                    body = "\n".join(f"[{i.severity}] {i.name} — {i.url}"
                                     for i in hits)
                    integrations.smtp_send(
                        cfg.get("host", ""), int(cfg.get("port", 587)),
                        cfg.get("user", ""), secret, cfg.get("from", ""),
                        to, f"[dast-triage] {len(hits)} {minsev}+ on {target.name}",
                        body, use_tls=bool(cfg.get("use_tls", True)))
        except Exception:  # noqa: BLE001
            traceback.print_exc()


# ---- scheduler -----------------------------------------------------------

def check_schedules(session: Session) -> int:
    """Enqueue scans for any schedule whose cron slot has passed. Returns count."""
    try:
        from croniter import croniter
    except ImportError:
        return 0
    now = utcnow()
    fired = 0
    for sch in session.scalars(select(Schedule).where(Schedule.enabled.is_(True))).all():
        try:
            itr = croniter(sch.cron, now)
            prev_slot = itr.get_prev(type(now))
        except Exception:
            continue
        last = sch.last_run
        # fire once per cron slot: due if we've never run, or last run predates this slot
        if last is not None and last.tzinfo is None:
            last = last.replace(tzinfo=now.tzinfo)
        if last is None or last < prev_slot:
            target = session.get(Target, sch.target_id)
            if target is None or not target.authorized:
                continue
            prof = session.get(ScanProfile, sch.profile_id) if sch.profile_id else None
            engines = list(sch.engines or []) or (prof.engines if prof else ["zap"])
            job = ScanJob(target_id=sch.target_id,
                          profile_id=(prof.id if prof else None),
                          engines=engines, status="queued",
                          created_by=f"schedule:{sch.id}",
                          full_scan=(prof.full_scan if prof else True))
            session.add(job)
            session.flush()
            sch.last_run = now
            sch.last_job_id = job.id
            fired += 1
    if fired:
        session.commit()
    return fired


# ---- the loop ------------------------------------------------------------

def _loop(session_factory):
    last_sched_check = 0.0
    while not _stop.is_set():
        try:
            s: Session = session_factory()
            # scheduler: check at most every 30s
            if time.time() - last_sched_check > 30:
                try:
                    check_schedules(s)
                except Exception:
                    traceback.print_exc()
                last_sched_check = time.time()
            job = s.scalar(
                select(ScanJob).where(ScanJob.status == "queued")
                .order_by(ScanJob.id.asc())
            )
            if job:
                run_job(s, job)
                s.close()
                continue
            s.close()
        except Exception:
            traceback.print_exc()
        _stop.wait(3)


def start(session_factory) -> None:
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, args=(session_factory,),
                               name="dast-scan-worker", daemon=True)
    _thread.start()


def stop() -> None:
    _stop.set()
