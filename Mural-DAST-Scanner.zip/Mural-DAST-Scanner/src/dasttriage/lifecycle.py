"""History matching and the issue lifecycle.

This module owns every state transition. Rules:

  * Ingesting a finding either matches an existing Issue by fingerprint (history
    carries forward) or creates a new one in state `new`.
  * A triage decision (false_positive / accepted_risk) made on an Issue sticks
    to its fingerprint and is inherited automatically when the same issue
    reappears in a later scan. That is the whole point: you triage once.
  * An Issue that was `open`/`reopened` and is absent from a fresh full scan is
    marked `fixed`. If it later reappears, it becomes `reopened` (NOT silently
    re-closed, and NOT reset to new).
  * `accepted_risk` carries an expiry. A sweep moves expired ones back to `open`.

Every transition writes a TriageEvent. Nothing mutates `state` without one.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from .db import Issue, Occurrence, ScanRun, Target, TriageEvent
from .models import RawFinding, TriageState, utcnow

# States that represent a human/agent decision we must not stomp on when the
# same issue shows up again in a later scan.
_DECISION_STATES = {TriageState.false_positive, TriageState.accepted_risk}
# States meaning "currently a live problem".
_ACTIVE_STATES = {TriageState.new, TriageState.open, TriageState.reopened}


def _record(
    session: Session,
    issue: Issue,
    to_state: TriageState,
    actor: str,
    reason: str | None = None,
    detail: dict | None = None,
) -> None:
    event = TriageEvent(
        issue_id=issue.id,
        from_state=issue.state,
        to_state=to_state.value,
        actor=actor,
        reason=reason,
        detail=detail or {},
    )
    issue.state = to_state.value
    session.add(event)


def get_or_create_target(session: Session, name: str) -> Target:
    tgt = session.scalar(select(Target).where(Target.name == name))
    if tgt is None:
        tgt = Target(name=name)
        session.add(tgt)
        session.flush()
    return tgt


def ingest(
    session: Session,
    target: Target,
    scan: ScanRun,
    finding: RawFinding,
) -> tuple[Issue, bool]:
    """Match `finding` to an Issue (or create one) and record an Occurrence.

    Returns (issue, is_new). Does not commit.
    """
    assert finding.fingerprint, "finding must be fingerprinted before ingest"
    issue = session.scalar(
        select(Issue).where(
            Issue.target_id == target.id,
            Issue.fingerprint == finding.fingerprint,
        )
    )
    is_new = issue is None
    now = utcnow()

    if is_new:
        issue = Issue(
            target_id=target.id,
            fingerprint=finding.fingerprint,
            name=finding.name,
            engine=finding.engine,
            engine_rule_id=finding.engine_rule_id,
            severity=finding.severity.value,
            cwe=finding.cwe,
            url=finding.url,
            param=finding.param or finding.evidence.param,
            method=finding.method,
            description=finding.description,
            remediation=finding.remediation,
            state=TriageState.new.value,
            first_seen=now,
            last_seen=now,
            times_seen=0,
        )
        session.add(issue)
        session.flush()
        _record(session, issue, TriageState.new, actor="system",
                reason="first observed")
    else:
        # History carries forward. Only a `fixed` issue reappearing changes
        # state here; decision states (fp/accepted) are left untouched so the
        # prior triage keeps suppressing/acknowledging it.
        if issue.state == TriageState.fixed.value:
            _record(session, issue, TriageState.reopened, actor="system",
                    reason="reappeared after being marked fixed")

    issue.last_seen = now
    issue.times_seen += 1
    # keep the display URL/severity fresh from the latest sighting
    issue.severity = finding.severity.value

    occ = Occurrence(
        issue_id=issue.id,
        scan_id=scan.id,
        confidence=finding.confidence.value,
        evidence=finding.evidence.model_dump(),
        raw=finding.raw,
    )
    session.add(occ)
    return issue, is_new


def close_absent_issues(
    session: Session,
    target: Target,
    scan: ScanRun,
    engines: list[str] | None = None,
) -> list[Issue]:
    """Mark active issues not seen in this (full) scan as fixed.

    Only call this for a full scan of the whole target; a partial/targeted scan
    must not close issues it never looked for. Decision states are never closed.

    Crucially, closing is scoped to the *engines that ran* in this scan: a full
    ZAP scan must not close issues only ZAP's peers (e.g. Nuclei) can find, or
    every full scan would ping-pong the other engines' findings fixed/reopened.
    If `engines` is None, fall back to the scan's recorded engine list.
    """
    engines = engines if engines is not None else (scan.engines or [])
    filters = [
        Issue.target_id == target.id,
        Issue.state.in_([s.value for s in _ACTIVE_STATES]),
    ]
    if engines:
        filters.append(Issue.engine.in_(engines))
    active = session.scalars(select(Issue).where(*filters)).all()
    seen_ids = {
        o.issue_id
        for o in session.scalars(
            select(Occurrence).where(Occurrence.scan_id == scan.id)
        ).all()
    }
    closed = []
    for issue in active:
        if issue.id not in seen_ids:
            _record(session, issue, TriageState.fixed, actor="system",
                    reason="absent from full scan")
            closed.append(issue)
    return closed


def set_triage(
    session: Session,
    issue: Issue,
    state: TriageState,
    actor: str,
    reason: str,
    accepted_until: datetime | None = None,
    ai_verdict: str | None = None,
    ai_confidence: float | None = None,
) -> None:
    """Apply a triage decision with required justification + audit trail."""
    if state == TriageState.accepted_risk and accepted_until is None:
        raise ValueError("accepted_risk requires an expiry (accepted_until)")
    if not reason or not reason.strip():
        raise ValueError("a triage decision requires a non-empty reason")

    issue.triage_reason = reason
    issue.triage_actor = actor
    issue.accepted_until = accepted_until
    if ai_verdict is not None:
        issue.ai_verdict = ai_verdict
        issue.ai_confidence = ai_confidence
    _record(session, issue, state, actor=actor, reason=reason,
            detail={"accepted_until": accepted_until.isoformat()
                    if accepted_until else None,
                    "ai_verdict": ai_verdict,
                    "ai_confidence": ai_confidence})


def expire_accepted_risks(session: Session, now: datetime | None = None) -> list[Issue]:
    """Move expired accepted-risk issues back to `open`. Run on every scan."""
    now = now or utcnow()
    expired = session.scalars(
        select(Issue).where(
            Issue.state == TriageState.accepted_risk.value,
            Issue.accepted_until.is_not(None),
            Issue.accepted_until < now,
        )
    ).all()
    for issue in expired:
        _record(session, issue, TriageState.open, actor="system",
                reason=f"accepted-risk expired at {issue.accepted_until}")
        issue.accepted_until = None
    return expired
