"""Stable fingerprinting of findings.

The fingerprint is the single most important piece of the system: it decides
whether a finding in today's scan is "the same issue" as one from last month.
Get it too loose and distinct bugs collapse together; too tight and every scan
invents brand-new findings, so triage decisions never carry forward.

Design rules:
  * Fingerprint from stable structure, never from volatile response bytes.
  * Collapse numeric / id-like path segments to a template: /user/123 -> /user/{id}.
  * Normalize the host (drop scheme, port when default, trailing slash, case).
  * Include engine rule id + param + method, since the same URL can host several
    distinct issues on different parameters.
  * Deliberately EXCLUDE: query-string values, timestamps, response length,
    the specific payload used. Those change run to run on the same bug.
"""
from __future__ import annotations

import hashlib
import re
from urllib.parse import urlsplit

from .models import RawFinding

_VERSION = "fp1"  # bump only with a migration; changing it orphans all history.

_DEFAULT_PORTS = {"http": "80", "https": "443"}

# Segments that look like ids and should be templated away.
_NUMERIC = re.compile(r"^\d+$")
_HEXLONG = re.compile(r"^[0-9a-fA-F]{8,}$")
_UUID = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
_MIXED_ID = re.compile(r"^(?=.*\d)[A-Za-z0-9._-]{12,}$")  # long mixed token


def normalize_host(url: str) -> str:
    parts = urlsplit(url if "://" in url else f"http://{url}")
    host = (parts.hostname or "").lower()
    port = parts.port
    scheme = parts.scheme or "http"
    if port and str(port) != _DEFAULT_PORTS.get(scheme, ""):
        return f"{host}:{port}"
    return host


def _template_segment(seg: str) -> str:
    if not seg:
        return seg
    if _NUMERIC.match(seg):
        return "{id}"
    if _UUID.match(seg):
        return "{uuid}"
    if _HEXLONG.match(seg):
        return "{hex}"
    if _MIXED_ID.match(seg):
        return "{id}"
    return seg.lower()


def normalize_path(url: str) -> str:
    """Return a path template with id-like segments collapsed.

    Query string is dropped entirely: its *presence* is captured via the param
    field on the finding, but its values are run-specific noise.
    """
    parts = urlsplit(url if "://" in url else f"http://{url}")
    path = parts.path or "/"
    segs = [_template_segment(s) for s in path.split("/")]
    templated = "/".join(segs)
    if len(templated) > 1 and templated.endswith("/"):
        templated = templated.rstrip("/")
    return templated or "/"


def compute(finding: RawFinding) -> str:
    """Deterministic fingerprint for a finding.

    Two findings share a fingerprint iff they agree on:
      engine rule, host, path-template, HTTP method, and parameter name.
    """
    host = normalize_host(finding.url)
    path = normalize_path(finding.url)
    param = (finding.param or finding.evidence.param or "").lower()
    method = (finding.method or "GET").upper()
    # engine_rule_id is namespaced by engine so ZAP id 40018 and a nuclei
    # template that happen to collide numerically never merge.
    rule = f"{finding.engine}:{finding.engine_rule_id}".lower()

    key = "|".join([_VERSION, rule, host, path, method, param])
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:32]
    return f"{_VERSION}_{digest}"


def explain(finding: RawFinding) -> dict[str, str]:
    """Human-readable breakdown of what went into the fingerprint (for audit)."""
    return {
        "version": _VERSION,
        "rule": f"{finding.engine}:{finding.engine_rule_id}",
        "host": normalize_host(finding.url),
        "path_template": normalize_path(finding.url),
        "method": (finding.method or "GET").upper(),
        "param": (finding.param or finding.evidence.param or ""),
    }
