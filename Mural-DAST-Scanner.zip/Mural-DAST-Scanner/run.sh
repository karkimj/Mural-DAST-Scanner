#!/usr/bin/env bash
# Linux runner (Azure VM, any Docker host). Equivalent of the Windows launcher.
#   ./run.sh <scope.yaml> <target-url> [engines]
# Example:
#   ./run.sh examples/scope.yaml https://app.internal.example.com zap,nuclei
set -euo pipefail

SCOPE="${1:?usage: run.sh <scope.yaml> <target-url> [engines]}"
TARGET="${2:?target URL required}"
ENGINES="${3:-zap}"
ZAP_KEY="${ZAP_API_KEY:-changeme}"
HERE="$(cd "$(dirname "$0")" && pwd)"
NET=dastnet

docker network create "$NET" 2>/dev/null || true

# ZAP engine (sidecar)
docker rm -f zap >/dev/null 2>&1 || true
docker run -d --name zap --network "$NET" -p 127.0.0.1:8080:8080 \
  ghcr.io/zaproxy/zaproxy:stable \
  zap.sh -daemon -host 0.0.0.0 -port 8080 \
  -config api.key="$ZAP_KEY" -config api.addrs.addr.name=.* -config api.addrs.addr.regex=true

# Scanner image + long-lived container
docker build -t dast-triage:latest -f "$HERE/docker/Dockerfile" "$HERE"
mkdir -p "$HERE/reports"
docker rm -f dast >/dev/null 2>&1 || true
docker run -d --name dast --network "$NET" \
  -v "$HERE/examples:/config:ro" \
  -v "$HERE/reports:/reports" \
  -v dast_data:/data \
  --entrypoint sleep dast-triage:latest infinity

# Wait for ZAP to be ready
echo "waiting for ZAP..."
for i in $(seq 1 60); do
  if curl -sf "http://localhost:8080/JSON/core/view/version/?apikey=${ZAP_KEY}" >/dev/null; then break; fi
  sleep 5
done

# Scan -> report
SCOPE_IN_CONTAINER="/config/$(basename "$SCOPE")"
docker exec dast dast scan "$SCOPE_IN_CONTAINER" "$TARGET" \
  --engines "$ENGINES" --zap-url http://zap:8080 --zap-key "$ZAP_KEY"
TARGET_NAME="$(docker exec dast python -c "import yaml,sys;print(yaml.safe_load(open('$SCOPE_IN_CONTAINER'))['name'])")"
docker exec dast dast findings "$TARGET_NAME"
docker exec dast dast report "$TARGET_NAME" --out /reports
echo "Reports in $HERE/reports/"
