"""Secret/PII redaction applied to evidence before it is ever stored.

Responses captured by a scanner routinely contain session cookies, bearer
tokens, API keys and PII. Those must not land in the database (and must not be
shipped to an external AI model later). Redaction happens once, here, at the
boundary between parse and persistence.

This is intentionally conservative pattern-matching, not a DLP product. For
sensitive targets, pair it with a local-only model and manual review.
"""
from __future__ import annotations

import re

from ..models import RawFinding

_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"(?i)(authorization:\s*bearer\s+)[a-z0-9._\-]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(cookie:\s*)[^\r\n]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(set-cookie:\s*)[^\r\n]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(x-api-key:\s*)[^\r\n]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(password\"?\s*[:=]\s*\"?)[^\"&\s]+"), r"\1[REDACTED]"),
    (re.compile(r"(?i)(token\"?\s*[:=]\s*\"?)[a-z0-9._\-]{8,}"), r"\1[REDACTED]"),
    # JWTs
    (re.compile(r"eyJ[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+\.[a-zA-Z0-9_\-]+"), "[JWT_REDACTED]"),
    # emails
    (re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"), "[EMAIL_REDACTED]"),
    # long bare secrets (AWS-style, hex keys)
    (re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "[AWS_KEY_REDACTED]"),
]


def redact_text(text: str | None) -> str | None:
    if not text:
        return text
    for pat, repl in _PATTERNS:
        text = pat.sub(repl, text)
    return text


def redact_finding(f: RawFinding) -> RawFinding:
    ev = f.evidence
    ev.request = redact_text(ev.request)
    ev.response_snippet = redact_text(ev.response_snippet)
    ev.other = {k: (redact_text(v) or "") for k, v in ev.other.items()}
    return f
