from dasttriage.fingerprint import compute, normalize_host, normalize_path
from dasttriage.models import RawFinding, Severity


def _f(url, rule="40018", engine="zap", param="id", method="GET"):
    return RawFinding(engine=engine, engine_rule_id=rule, name="x",
                      severity=Severity.high, url=url, param=param, method=method)


def test_path_templating_collapses_ids():
    assert normalize_path("https://h/user/123/profile") == "/user/{id}/profile"
    assert normalize_path("https://h/u/9f8e7d6c5b4a3210") == "/u/{hex}"
    u = "https://h/orders/550e8400-e29b-41d4-a716-446655440000"
    assert normalize_path(u) == "/orders/{uuid}"


def test_host_normalization_drops_default_port_and_case():
    assert normalize_host("https://Staging.Example.com:443/x") == "staging.example.com"
    assert normalize_host("http://h:8080/x") == "h:8080"


def test_same_issue_different_query_value_same_fingerprint():
    # The whole point: a rescan with a different id in the query must match.
    a = compute(_f("https://staging.example.com/products?id=5"))
    b = compute(_f("https://staging.example.com/products?id=777"))
    assert a == b


def test_different_param_different_fingerprint():
    a = compute(_f("https://h/products?id=5", param="id"))
    b = compute(_f("https://h/products?id=5", param="name"))
    assert a != b


def test_different_engine_rule_different_fingerprint():
    a = compute(_f("https://h/x", rule="40018"))
    b = compute(_f("https://h/x", rule="40019"))
    assert a != b


def test_fingerprint_is_stable_string():
    fp = compute(_f("https://h/x"))
    assert fp.startswith("fp1_")
    assert compute(_f("https://h/x")) == fp
