"""Nuclei adapter.

Nuclei emits one JSON object per line (JSONL) with `-jsonl`. We parse that
offline, and `scan` shells out to the `nuclei` binary writing JSONL to a temp
file. Nuclei findings are template-matched and carry low false-positive rates,
so most need little triage.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path

from ..config import ScopeConfig
from ..models import Confidence, Evidence, RawFinding, Severity
from .base import Engine

_SEV_MAP = {
    "info": Severity.info,
    "low": Severity.low,
    "medium": Severity.medium,
    "high": Severity.high,
    "critical": Severity.critical,
    "unknown": Severity.info,
}


class NucleiEngine(Engine):
    name = "nuclei"

    def __init__(self, binary: str = "nuclei"):
        self.binary = binary

    def _one(self, obj: dict) -> RawFinding:
        info = obj.get("info", {})
        sev = _SEV_MAP.get((info.get("severity") or "info").lower(), Severity.info)
        url = obj.get("matched-at") or obj.get("host") or obj.get("matched") or ""
        classification = info.get("classification") or {}
        cwe_ids = classification.get("cwe-id") or []
        cwe = None
        if cwe_ids:
            m = "".join(c for c in str(cwe_ids[0]) if c.isdigit())
            cwe = int(m) if m else None
        return RawFinding(
            engine=self.name,
            engine_rule_id=obj.get("template-id", "unknown"),
            name=info.get("name", obj.get("template-id", "nuclei finding")),
            severity=sev,
            confidence=Confidence.high,  # template match
            url=url,
            method=(obj.get("type") or "http").upper() if obj.get("type") in {"http", "dns"} else "GET",
            cwe=cwe,
            description=info.get("description", "") or "",
            remediation=info.get("remediation", "") or "",
            references=info.get("reference") or [],
            evidence=Evidence(
                url=url,
                attack=obj.get("matcher-name"),
                request=obj.get("request"),
                response_snippet=(obj.get("response") or "")[:4000] or None,
                other={"template": obj.get("template", "")},
            ),
            raw=obj,
        )

    def parse(self, payload: str | bytes | dict) -> list[RawFinding]:
        if isinstance(payload, dict):
            return [self._one(payload)]
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8", "replace")
        findings = []
        for line in payload.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                findings.append(self._one(json.loads(line)))
            except json.JSONDecodeError:
                continue
        return findings

    def scan(self, target: str, scope: ScopeConfig,
             headers: dict[str, str] | None = None,
             tags: list[str] | None = None) -> list[RawFinding]:
        scope.assert_in_scope(target)
        if shutil.which(self.binary) is None:
            raise RuntimeError(f"{self.binary} not found on PATH")
        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "nuclei.jsonl"
            cmd = [
                self.binary, "-u", target, "-jsonl", "-o", str(out),
                "-rate-limit", str(int(scope.max_rps)), "-silent",
            ]
            if not scope.verifier.allow_active_exploit:
                cmd.append("-no-interactsh")
            for k, v in (headers or {}).items():
                cmd += ["-H", f"{k}: {v}"]
            if tags:
                cmd += ["-tags", ",".join(tags)]
            subprocess.run(cmd, check=False, capture_output=True, timeout=3600)
            if not out.exists():
                return []
            return self.parse(out.read_text())
