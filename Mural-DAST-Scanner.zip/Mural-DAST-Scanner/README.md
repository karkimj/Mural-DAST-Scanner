# dast-triage

An open-source DAST **platform**: schedule and run web scans (OWASP ZAP + Nuclei), keep **historical findings** across scans, triage **false positives / accepted risks**, and ship a **clean report** free of false positives — all behind a password-protected web UI with role-based access. Runs anywhere Docker runs.

**What's inside**
- **Targets** with auth config (basic / bearer / header / cookie / form login), scope, API specs, and an authorization attestation.
- **Scans**: run-now + **cron schedules**, an in-process worker queue, live status and logs.
- **Findings & triage**: stable fingerprinting so an issue is recognised across scans; `new → open → {false_positive | accepted_risk | fixed}` lifecycle that survives rescans; mark false positives once and they stay suppressed; accept a risk with a mandatory expiry and it auto-reopens.
- **Reports**: clean HTML / JSON / SARIF (open findings in the body, accepted risks in an appendix, false positives counted but excluded).
- **Scan management**: engine health, Nuclei template updates, scan-profile editor.
- **Integrations**: DefectDojo (SARIF push), Slack and SMTP notifications on new findings.
- **Users**: Admin / Analyst / Viewer roles; credentials and tokens encrypted at rest (Fernet).

## Quick start (Linux, Docker)

```bash
git clone <this-repo> dast-triage && cd dast-triage
cp .env.example .env
# generate secrets and put them in .env:
python3 -c "import secrets;print('DAST_SECRET_KEY='+secrets.token_hex(32))"
python3 -c "from cryptography.fernet import Fernet;print('DAST_FERNET_KEY='+Fernet.generate_key().decode())"
# edit .env: set DAST_WEB_PASSWORD, paste the two keys above, set ZAP_API_KEY

docker compose -f docker/docker-compose.yml --env-file .env up -d --build
```

Open **http://127.0.0.1:8000** and sign in with `DAST_WEB_USER` / `DAST_WEB_PASSWORD`.
It binds to localhost by design — put a TLS-terminating reverse proxy (Caddy/nginx) in front before exposing it, then set `DAST_HTTPS_ONLY=true`.

Then in the UI: add a **Target** (tick the authorization box), optionally set up a **Schedule**, and hit **Run now**.

## CLI (optional, offline-friendly)

```bash
pip install -e .
dast import myapp zap path/to/zap-report.json --full   # ingest a saved report
dast findings myapp
dast triage 1 accept --reason "compensating control" --days 30
dast report myapp --out reports                         # html / json / sarif
dast serve                                              # run the web UI directly
```

A **scope file is mandatory** for CLI live scans — the scanner refuses to run without `include_hosts`. See `examples/scope.yaml`.

## Architecture

```
engines/{zap,nuclei}  → normalize → redact → fingerprint → lifecycle.ingest
                                                                │
          history match by fingerprint ─────────┐              │
                                                 ▼              ▼
                                    inherit prior triage   Issue + Occurrence + TriageEvent
                                                 │
                                                 ▼
                                   report  (clean HTML / JSON / SARIF)
```

- **`models.py`** — engine-agnostic `RawFinding`, severities, triage states.
- **`fingerprint.py`** — path-templating + stable hash. The heart of history.
- **`config.py`** — scope file + mandatory scope enforcement.
- **`db.py`** — `Target / ScanRun / Issue / Occurrence / TriageEvent` (DefectDojo-shaped).
- **`lifecycle.py`** — every state transition, each writing an audit event.
- **`engines/`** — adapters; `parse()` is pure/offline, `scan()` drives the live tool. `redact.py` strips secrets/PII before anything is stored.
- **`report/`** — clean HTML, JSON, and SARIF (for GitHub/GitLab code-scanning).

## Design decisions worth knowing

- **Fingerprint from structure, not bytes.** Query-string *values*, timestamps, response length and the specific payload are deliberately excluded; engine rule + host + path-template + method + param are included. Changing the fingerprint version (`fp1`) orphans history, so it only changes with a migration.
- **A full scan only closes findings from the engines that ran.** Otherwise a full ZAP scan would mark Nuclei's findings fixed, and the next Nuclei run would reopen them, forever.
- **Decisions are never silently overwritten.** A reappearing false-positive stays suppressed; it is not auto-closed as fixed and not reset to new.
- **Accepted risk requires an expiry and a reason.** No permanent sweep-under-the-rug.
- **Redaction happens at the storage boundary**, so secrets never reach the DB or (later) an external model.

## Roadmap

- **Phase 2** — authenticated scanning (Playwright login + ZAP contexts), DefectDojo export.
- **Phase 3** — verifier stage (sqlmap / Dalfox / Commix confirming findings) + AI triage agent via an MCP tool server, running in shadow mode first.
- **Phase 4** — Burp Pro adapter (mounted jar + license, never baked into the image — licence terms permitting), interactsh out-of-band detection.
- **Phase 5** — triage web UI, false-positive-rate and model-accuracy metrics.

## Tests

```bash
pytest -q
```

Covers fingerprint stability, the full lifecycle (carry-forward, fixed/reopened, expiry, cross-engine closing), parsing, redaction and reporting.
