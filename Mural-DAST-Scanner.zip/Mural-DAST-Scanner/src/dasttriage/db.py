"""Persistence layer.

Schema is deliberately close to DefectDojo's mental model so an export path is
straightforward later:

  Target      - a logical application (groups scans + issues)
  ScanRun     - one execution of one or more engines against a target
  Issue       - a deduplicated finding, keyed by fingerprint; carries the
                triage state that must survive across scans
  Occurrence  - one sighting of an Issue in one ScanRun, with its evidence
  TriageEvent - append-only audit log of every state change

The split between Issue (durable, triaged) and Occurrence (per-scan, with
evidence) is what lets a false-positive or accepted-risk decision persist while
still recording every time the issue was seen.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from sqlalchemy import (
    JSON,
    DateTime,
    ForeignKey,
    String,
    Text,
    create_engine,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
    sessionmaker,
)

from .models import TriageState, utcnow


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(128), unique=True)
    password_hash: Mapped[str] = mapped_column(Text)
    role: Mapped[str] = mapped_column(String(16), default="viewer")  # admin|analyst|viewer
    is_active: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_login: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)


class Target(Base):
    __tablename__ = "targets"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    # identity
    description: Mapped[str] = mapped_column(Text, default="")
    environment: Mapped[str] = mapped_column(String(16), default="prod")
    criticality: Mapped[str] = mapped_column(String(16), default="medium")
    owner: Mapped[str] = mapped_column(String(128), default="")
    tags: Mapped[list | None] = mapped_column(JSON, default=list)
    # surface
    base_urls: Mapped[list | None] = mapped_column(JSON, default=list)
    extra_hosts: Mapped[list | None] = mapped_column(JSON, default=list)
    api_spec_url: Mapped[str] = mapped_column(Text, default="")
    api_spec_type: Mapped[str] = mapped_column(String(16), default="")  # openapi|graphql
    # scope
    include_hosts: Mapped[list | None] = mapped_column(JSON, default=list)
    exclude_hosts: Mapped[list | None] = mapped_column(JSON, default=list)
    exclude_paths: Mapped[list | None] = mapped_column(JSON, default=list)
    max_rps: Mapped[float] = mapped_column(default=10.0)
    # authentication
    auth_method: Mapped[str] = mapped_column(String(16), default="none")  # none|basic|bearer|header|cookie|form
    auth_login_url: Mapped[str] = mapped_column(Text, default="")
    auth_username_field: Mapped[str] = mapped_column(String(128), default="")
    auth_password_field: Mapped[str] = mapped_column(String(128), default="")
    auth_header_name: Mapped[str] = mapped_column(String(128), default="")
    auth_logged_in_regex: Mapped[str] = mapped_column(Text, default="")
    auth_reauth_seconds: Mapped[int] = mapped_column(default=0)
    # safety / verifier
    allow_active_exploit: Mapped[bool] = mapped_column(default=False)
    sqlmap_level: Mapped[int] = mapped_column(default=1)
    sqlmap_risk: Mapped[int] = mapped_column(default=1)
    tech_hints: Mapped[list | None] = mapped_column(JSON, default=list)
    # authorization attestation
    authorized: Mapped[bool] = mapped_column(default=False)
    authorized_by: Mapped[str | None] = mapped_column(String(128), nullable=True)
    authorized_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    notify_emails: Mapped[list | None] = mapped_column(JSON, default=list)

    scans: Mapped[list["ScanRun"]] = relationship(back_populates="target")
    issues: Mapped[list["Issue"]] = relationship(back_populates="target")
    credentials: Mapped[list["Credential"]] = relationship(back_populates="target")


class Credential(Base):
    """Target auth secret, encrypted at rest (see crypto.py)."""
    __tablename__ = "credentials"
    id: Mapped[int] = mapped_column(primary_key=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("targets.id"))
    kind: Mapped[str] = mapped_column(String(32), default="password")  # password|token|basic
    username: Mapped[str] = mapped_column(String(255), default="")
    secret_encrypted: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    target: Mapped["Target"] = relationship(back_populates="credentials")


class ScanProfile(Base):
    __tablename__ = "scan_profiles"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(64), unique=True)
    description: Mapped[str] = mapped_column(Text, default="")
    engines: Mapped[list | None] = mapped_column(JSON, default=list)       # ["zap","nuclei"]
    nuclei_tags: Mapped[list | None] = mapped_column(JSON, default=list)
    zap_policy: Mapped[str] = mapped_column(String(64), default="")
    time_budget_seconds: Mapped[int] = mapped_column(default=0)
    full_scan: Mapped[bool] = mapped_column(default=True)


class ScanJob(Base):
    """A queued/running scan. The worker processes these FIFO."""
    __tablename__ = "scan_jobs"
    id: Mapped[int] = mapped_column(primary_key=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("targets.id"))
    profile_id: Mapped[int | None] = mapped_column(ForeignKey("scan_profiles.id"), nullable=True)
    engines: Mapped[list | None] = mapped_column(JSON, default=list)
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued|running|completed|failed|canceled
    full_scan: Mapped[bool] = mapped_column(default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_by: Mapped[str] = mapped_column(String(128), default="")
    scan_run_id: Mapped[int | None] = mapped_column(ForeignKey("scan_runs.id"), nullable=True)
    result: Mapped[dict | None] = mapped_column(JSON, default=dict)
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    log: Mapped[str | None] = mapped_column(Text, default="")


class ScanRun(Base):
    __tablename__ = "scan_runs"
    id: Mapped[int] = mapped_column(primary_key=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("targets.id"))
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    engines: Mapped[list | None] = mapped_column(JSON, default=list)
    meta: Mapped[dict | None] = mapped_column(JSON, default=dict)
    target: Mapped["Target"] = relationship(back_populates="scans")
    occurrences: Mapped[list["Occurrence"]] = relationship(back_populates="scan")


class Issue(Base):
    __tablename__ = "issues"
    id: Mapped[int] = mapped_column(primary_key=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("targets.id"))
    fingerprint: Mapped[str] = mapped_column(String(64), index=True)
    name: Mapped[str] = mapped_column(String(512))
    engine: Mapped[str] = mapped_column(String(32))
    engine_rule_id: Mapped[str] = mapped_column(String(128))
    severity: Mapped[str] = mapped_column(String(16))
    cwe: Mapped[int | None] = mapped_column(nullable=True)
    url: Mapped[str] = mapped_column(Text)
    param: Mapped[str | None] = mapped_column(String(255), nullable=True)
    method: Mapped[str] = mapped_column(String(8), default="GET")
    description: Mapped[str] = mapped_column(Text, default="")
    remediation: Mapped[str] = mapped_column(Text, default="")

    state: Mapped[str] = mapped_column(String(32), default=TriageState.new.value)
    # triage metadata (nullable until a decision is made)
    triage_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    triage_actor: Mapped[str | None] = mapped_column(String(128), nullable=True)
    # AI-proposed verdict kept separate from the human-authoritative state
    ai_verdict: Mapped[str | None] = mapped_column(String(32), nullable=True)
    ai_confidence: Mapped[float | None] = mapped_column(nullable=True)
    # accepted-risk expiry: when passed, the issue auto-reopens
    accepted_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    first_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_seen: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    times_seen: Mapped[int] = mapped_column(default=0)

    target: Mapped["Target"] = relationship(back_populates="issues")
    occurrences: Mapped[list["Occurrence"]] = relationship(back_populates="issue")
    events: Mapped[list["TriageEvent"]] = relationship(back_populates="issue")


class Occurrence(Base):
    __tablename__ = "occurrences"
    id: Mapped[int] = mapped_column(primary_key=True)
    issue_id: Mapped[int] = mapped_column(ForeignKey("issues.id"))
    scan_id: Mapped[int] = mapped_column(ForeignKey("scan_runs.id"))
    seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    confidence: Mapped[str] = mapped_column(String(16), default="medium")
    evidence: Mapped[dict | None] = mapped_column(JSON, default=dict)
    raw: Mapped[dict | None] = mapped_column(JSON, default=dict)
    issue: Mapped["Issue"] = relationship(back_populates="occurrences")
    scan: Mapped["ScanRun"] = relationship(back_populates="occurrences")


class TriageEvent(Base):
    """Append-only. Never updated or deleted; the full history of a decision."""
    __tablename__ = "triage_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    issue_id: Mapped[int] = mapped_column(ForeignKey("issues.id"))
    at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    actor: Mapped[str] = mapped_column(String(128))       # "human:mj", "agent:triage", "system"
    from_state: Mapped[str | None] = mapped_column(String(32), nullable=True)
    to_state: Mapped[str] = mapped_column(String(32))
    reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    detail: Mapped[dict | None] = mapped_column(JSON, default=dict)
    issue: Mapped["Issue"] = relationship(back_populates="events")


class Schedule(Base):
    """A recurring scan definition. The scheduler enqueues ScanJobs when due."""
    __tablename__ = "schedules"
    id: Mapped[int] = mapped_column(primary_key=True)
    target_id: Mapped[int] = mapped_column(ForeignKey("targets.id"))
    name: Mapped[str] = mapped_column(String(128), default="")
    profile_id: Mapped[int | None] = mapped_column(ForeignKey("scan_profiles.id"), nullable=True)
    engines: Mapped[list | None] = mapped_column(JSON, default=list)
    cron: Mapped[str] = mapped_column(String(64), default="0 2 * * *")
    enabled: Mapped[bool] = mapped_column(default=True)
    created_by: Mapped[str] = mapped_column(String(128), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    last_run: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_job_id: Mapped[int | None] = mapped_column(nullable=True)


class Integration(Base):
    """External integration: DefectDojo, Slack webhook, or SMTP email.

    Non-secret config is JSON; the primary secret (API key / webhook URL /
    SMTP password) is encrypted at rest.
    """
    __tablename__ = "integrations"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(32))  # defectdojo|slack|smtp
    name: Mapped[str] = mapped_column(String(128), default="")
    enabled: Mapped[bool] = mapped_column(default=True)
    config: Mapped[dict | None] = mapped_column(JSON, default=dict)
    secret_encrypted: Mapped[str] = mapped_column(Text, default="")
    notify_min_severity: Mapped[str] = mapped_column(String(16), default="high")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


def make_engine(url: str | None = None):
    """SQLite by default (single-machine), Postgres via DAST_DB_URL."""
    import os

    url = url or os.environ.get("DAST_DB_URL") or "sqlite:///dast.db"
    connect_args = {}
    if url.startswith("sqlite"):
        # the worker thread and request threads share the engine
        connect_args = {"check_same_thread": False, "timeout": 30}
        p = url.replace("sqlite:///", "", 1)
        if p and p != ":memory:":
            Path(p).parent.mkdir(parents=True, exist_ok=True)
    return create_engine(url, future=True, connect_args=connect_args)


def _add_column_sql(dialect, table: str, col) -> str:
    import sqlalchemy as sa

    coltype = col.type.compile(dialect=dialect)
    parts = [f'ALTER TABLE {table} ADD COLUMN "{col.name}" {coltype}']
    if not col.nullable:
        t = col.type
        if isinstance(t, (sa.Integer, sa.Float, sa.Numeric, sa.Boolean)):
            default = "0"
        else:
            default = "''"
        parts.append(f"NOT NULL DEFAULT {default}")
    return " ".join(parts)


def migrate(engine) -> None:
    """Add any model columns missing from existing tables (lightweight, no Alembic).

    New tables are handled by create_all; this only patches tables that predate
    a schema change so old databases keep working after an upgrade.
    """
    from sqlalchemy import inspect, text

    import sys

    insp = inspect(engine)
    existing = set(insp.get_table_names())
    added = []
    for table in Base.metadata.sorted_tables:
        if table.name not in existing:
            continue
        have = {c["name"] for c in insp.get_columns(table.name)}
        for col in table.columns:
            if col.name in have:
                continue
            ddl = _add_column_sql(engine.dialect, table.name, col)
            try:
                with engine.begin() as conn:
                    conn.execute(text(ddl))
                added.append(f"{table.name}.{col.name}")
            except Exception as e:  # noqa: BLE001
                sys.stderr.write(f"[migrate] FAILED {ddl!r}: {e}\n")
    if added:
        sys.stderr.write(f"[migrate] added columns: {', '.join(added)}\n")
    else:
        sys.stderr.write("[migrate] schema already current\n")


def init_db(engine) -> None:
    Base.metadata.create_all(engine)
    migrate(engine)


def make_session(engine):
    return sessionmaker(bind=engine, expire_on_commit=False, future=True)
