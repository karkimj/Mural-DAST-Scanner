"""External integrations: DefectDojo, Slack, SMTP email.

Each has a `test` (connection check) and a `send`/`push` action. Secrets are
passed in decrypted by the caller (web layer / worker), never stored here.
"""
from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage

import httpx

_SEV_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def min_sev_ok(severity: str, minimum: str) -> bool:
    return _SEV_RANK.get(severity, 0) >= _SEV_RANK.get(minimum, 3)


# ---- DefectDojo ----------------------------------------------------------
def defectdojo_test(url: str, api_key: str) -> tuple[bool, str]:
    url = url.rstrip("/")
    try:
        r = httpx.get(f"{url}/api/v2/user_profile/",
                      headers={"Authorization": f"Token {api_key}"}, timeout=20)
        if r.status_code == 200:
            return True, "connected"
        return False, f"HTTP {r.status_code}: {r.text[:120]}"
    except httpx.HTTPError as e:
        return False, str(e)


def defectdojo_push(url: str, api_key: str, engagement_id: int,
                    sarif_text: str, scan_name: str) -> tuple[bool, str]:
    """Import a SARIF report into a DefectDojo engagement (dedup handled there)."""
    url = url.rstrip("/")
    try:
        files = {"file": (f"{scan_name}.sarif", sarif_text, "application/json")}
        data = {
            "scan_type": "SARIF",
            "engagement": str(engagement_id),
            "active": "true", "verified": "false",
            "close_old_findings": "false",
        }
        r = httpx.post(f"{url}/api/v2/import-scan/",
                       headers={"Authorization": f"Token {api_key}"},
                       data=data, files=files, timeout=60)
        if r.status_code in (200, 201):
            return True, "imported"
        return False, f"HTTP {r.status_code}: {r.text[:160]}"
    except httpx.HTTPError as e:
        return False, str(e)


# ---- Slack / webhook -----------------------------------------------------
def slack_test(webhook: str) -> tuple[bool, str]:
    return slack_send(webhook, "dast-triage: test message ✅")


def slack_send(webhook: str, text: str) -> tuple[bool, str]:
    try:
        r = httpx.post(webhook, json={"text": text}, timeout=20)
        if r.status_code in (200, 204):
            return True, "sent"
        return False, f"HTTP {r.status_code}: {r.text[:120]}"
    except httpx.HTTPError as e:
        return False, str(e)


# ---- SMTP email ----------------------------------------------------------
def smtp_send(host: str, port: int, user: str, password: str,
              mail_from: str, mail_to: list[str], subject: str,
              body: str, use_tls: bool = True) -> tuple[bool, str]:
    try:
        msg = EmailMessage()
        msg["From"] = mail_from
        msg["To"] = ", ".join(mail_to)
        msg["Subject"] = subject
        msg.set_content(body)
        if use_tls:
            ctx = ssl.create_default_context()
            with smtplib.SMTP(host, port, timeout=30) as s:
                s.starttls(context=ctx)
                if user:
                    s.login(user, password)
                s.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=30) as s:
                if user:
                    s.login(user, password)
                s.send_message(msg)
        return True, "sent"
    except Exception as e:  # noqa: BLE001
        return False, str(e)
